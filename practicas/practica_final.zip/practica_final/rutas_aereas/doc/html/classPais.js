var classPais =
[
    [ "Pais", "classPais.html#ae61c25e4d6d256fc86b8fd4496443188", null ],
    [ "GetBandera", "classPais.html#a32bea79d87cd10e4b3e5a5e760b6fe54", null ],
    [ "GetPais", "classPais.html#afcb6d20c9ccdb2e1c44e59f0a98bc485", null ],
    [ "GetPunto", "classPais.html#abc5c5f50839be6df8ca68d58a79100c0", null ],
    [ "operator<", "classPais.html#a62302c75f0b6bfa28c191310edb116dc", null ],
    [ "operator==", "classPais.html#a21667d0218e8506d4608443ace70908b", null ],
    [ "operator==", "classPais.html#ad5a51297df3167414869cdb476822b8f", null ],
    [ "operator<<", "classPais.html#a6d1c962b239638bd10f4a58a5aeaa6d5", null ],
    [ "operator>>", "classPais.html#aacd6663db9fb049ff7041c93f4bdbf6a", null ],
    [ "bandera", "classPais.html#a367c39694a5a5d45523298003c5ef009", null ],
    [ "p", "classPais.html#a5e3ea7c2d436a3f80cd6953db7e4995b", null ],
    [ "pais", "classPais.html#ab7f8350a6cb17f1e924f2b9f4616d8a9", null ]
];