var imagen_8h =
[
    [ "Pixel", "structPixel.html", "structPixel" ],
    [ "Imagen", "classImagen.html", "classImagen" ],
    [ "Tipo_Pegado", "imagen_8h.html#a573504250cd1401cf4e53b1e756d38f2", [
      [ "OPACO", "imagen_8h.html#a573504250cd1401cf4e53b1e756d38f2aa79b13de65635e719e4b59b6750c572b", null ],
      [ "BLENDING", "imagen_8h.html#a573504250cd1401cf4e53b1e756d38f2aab7efbd0af1a19f6d001e6140626e739", null ]
    ] ]
];