var Punto_8h =
[
    [ "Punto", "classPunto.html", "classPunto" ],
    [ "operator<<", "Punto_8h.html#a087d8093af21652931916f49d5698ec1", null ],
    [ "operator>>", "Punto_8h.html#a31128d021f3e7062da16ccae225b9c68", null ]
];