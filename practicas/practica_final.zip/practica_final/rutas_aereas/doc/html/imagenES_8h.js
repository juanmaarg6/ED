var imagenES_8h =
[
    [ "TipoImagen", "imagenES_8h.html#a8914f6544a484741b05c092d9e7522ed", [
      [ "IMG_DESCONOCIDO", "imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda23c8d70e6eadf2d0d0ee1fd3bb293384", null ],
      [ "IMG_PGM", "imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda8fbef75c1a0002dd6099c6cc1a43e441", null ],
      [ "IMG_PPM", "imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda1269c51434b906a7e507f5b49663bf4f", null ]
    ] ],
    [ "EscribirImagenPGM", "imagenES_8h.html#abf2397dda9f7cde383655b0a081b7c93", null ],
    [ "EscribirImagenPPM", "imagenES_8h.html#a420de11a71f00b579f392e94f0d2498e", null ],
    [ "LeerImagenPGM", "imagenES_8h.html#a7989c5e096410d5bb9ac230b53ab1304", null ],
    [ "LeerImagenPPM", "imagenES_8h.html#a4a6f0611d8fe9496ad0f3525e29684de", null ],
    [ "LeerTipoImagen", "imagenES_8h.html#a4ba3a13a2951f968a61b3d60b06c8784", null ]
];