var Pais_8h =
[
    [ "Pais", "classPais.html", "classPais" ],
    [ "operator<<", "Pais_8h.html#a6d1c962b239638bd10f4a58a5aeaa6d5", null ],
    [ "operator>>", "Pais_8h.html#aacd6663db9fb049ff7041c93f4bdbf6a", null ]
];