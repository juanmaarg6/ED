#!/bin/bash
#Autor: Juan Manuel Rodriguez Gomez

./bin/rutas_aereas ./datos/paises.txt ./datos/imagenes/mapas/mapa1.ppm ./datos/imagenes/banderas/ ./datos/almacen_rutas.txt ./datos/imagenes/aviones/avion1.ppm ./datos/imagenes/aviones/mascara_avion1.pgm
