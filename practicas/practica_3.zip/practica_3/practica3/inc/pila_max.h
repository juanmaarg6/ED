/**
 * @file pila_max.h
 * @author David Mu�oz S�nchez
 * @author Juan Manuel Rodr�guez G�mez
 */

#include <iostream>

#define CUAL_COMPILA 1

#if CUAL_COMPILA==1
    #include <pila_max_vd.h>
    typedef Pila_max_VD Pila_max;
#elif CUAL_COMPILA==2
    #include <pila_max_cola.h>
    typedef Pila_max_Cola Pila_max;
#endif
