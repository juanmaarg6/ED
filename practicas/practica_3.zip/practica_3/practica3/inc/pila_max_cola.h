/**
 * @file pila_max_cola.h
 * @author David Muñoz Sánchez
 * @author Juan Manuel Rodríguez Gómez
 */

#ifndef PILA_MAX_COLA_H
#define PILA_MAX_COLA_H

#include <iostream>
#include "cola.h"


/**
 * @brief Estructura usada en la pila formada por un elemento de la pila y el m�ximo de dicha pila
 */
struct elemento{

    int ele;    /**< Elemento de la pila */
    int maximo; /**< M�ximo de la pila */

};

/**
 * @class Pila_max_Cola
 * @brief Clase creada para representar una pila usando colas
 */
class Pila_max_Cola{

    private:

        Cola<elemento> cola;	/**< Cola de enteros */

    public:

	/**
	 * @brief Constructor por defecto
	 */
	Pila_max_Cola();
	    
    /**
     * @brief Constructor de copia
     * @param p Pila que se va a copiar
     */
    Pila_max_Cola(const Pila_max_Cola& p);

	/**
	 * @brief Operador de asignacion
	 * @param p Pila que vamos a asignar
	 * @return this Referencia de la pila actual
	 */
	Pila_max_Cola& operator=(const Pila_max_Cola& p);
	    
	/**
	 * @brief Destructor
	 */
	~Pila_max_Cola();

	/**
	 * @brief Comprueba si la pila est� vac�a
	 * @return True (1) si la pila est� vac�a y False (0) si no lo est�
	 */
	bool vacia() const;

    /**
	 * @brief Devuelve el elemento del tope de la pila
     * @return Tope de la pila
	 */
	elemento& tope();

	/**
	 * @brief Devuelve el elemento del tope de una pila constante
     * @return Tope de la pila constante
	 */
	const elemento& tope() const;

	/**
	 * @brief A�ade un elemento "encima" del tope de la pila
	 * @param elem Elemento que se va a a�adir
	 */
	void poner(int elem);
	    
	/**
	 * @brief Quita el elemento del tope de la pila
	 */
    void quitar();

    /**
	 * @brief Devuelve el n�mero de elementos de la pila
     * @return N�mero de elementos de la pila
	 */
	int num_elementos() const;

};

#endif /* PILA_MAX_COLA_H */
