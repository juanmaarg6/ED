/**
 * @file pila_max_vd.h
 * @author David Muñoz Sánchez
 * @author Juan Manuel Rodríguez Gómez
 */

#ifndef PILA_MAX_VD_H
#define PILA_MAX_VD_H

#include <iostream>
#include <vector>


/**
 * @brief Estructura usada en la pila formada por un elemento de la pila y el máximo de dicha pila
 */
struct elemento{

    int ele;    /**< Elemento de la pila */
    int maximo; /**< Máximo de la pila */

};

/**
 * @class Pila_max_VD
 * @brief Clase usada para representar una pila mediante vectores dinámicos
 */
class Pila_max_VD {

    private:
    
        std::vector<elemento> vector_elementos; /**< Vector dinámico de struct elemento */

    public:

        /**
         * @brief Constructor por defecto
         */
        Pila_max_VD();

        /**
         * @brief Constructor de copia
         * @param p Pila a copiar
         */
        Pila_max_VD(const Pila_max_VD& p);

        /**
         * @brief Operador de asignación
         * @param p Pila que vamos a asignar
         * @return Referencia a la pila actual
         */
        Pila_max_VD& operator=(const Pila_max_VD& p);

        /**
         * @brief Destructor
         */
        ~Pila_max_VD();

        /**
         * @brief Comprueba si la pila está vacía
         * @return True (1) si la pila está vacía y False (0) si no lo está
         */
        bool vacia() const;

        /**
         * @brief Devuelve el elemento del tope de la pila
         * @return Tope de la pila
         */
        elemento& tope();

 	    /**
	     * @brief Devuelve el elemento del tope de una pila constante
         * @return Tope de la pila constante
	     */
        const elemento& tope() const;

        /**
         * @brief Añade un elemento "encima" del tope de la pila
         * @param elem Elemento que se va a añadir
         */
        void poner(int elem);

        /**
         * @brief Quita el elemento del tope de la pila
         */
        void quitar();

        /**
         * @brief Devuelve el número de elementos de la pila
         * @return Número de elementos de la pila
         */
        int num_elementos() const;
};

#endif /* PILA_MAX_VD_H */
