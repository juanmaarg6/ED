/**
 * @file pila_max_vd.cpp
 * @author David Mu�oz S�nchez
 * @author Juan Manuel Rodr�guez G�mez
 */

#include "pila_max_vd.h"

using namespace std;

Pila_max_VD::Pila_max_VD() {
}

Pila_max_VD::Pila_max_VD(const Pila_max_VD& p)
            :vector_elementos(p.vector_elementos) { 
}

Pila_max_VD& Pila_max_VD::operator=(const Pila_max_VD& p) {
    if(this != &p)
        this->vector_elementos = p.vector_elementos;

    return *this;
}

Pila_max_VD::~Pila_max_VD() {
}

bool Pila_max_VD::vacia() const {
    return vector_elementos.empty();
}

elemento& Pila_max_VD::tope() {
    return vector_elementos.back();
}

const elemento& Pila_max_VD::tope() const {
    return vector_elementos.back();
}

void Pila_max_VD::poner(int elem) {

    elemento x = {elem, elem};
    bool vacia = this->vacia();

    if (!vacia){
        if(tope().maximo > elem)
            x.maximo = tope().maximo;
    }

    vector_elementos.push_back(x);
}

void Pila_max_VD::quitar() {
    if(!vacia())
        vector_elementos.pop_back();
}

int Pila_max_VD::num_elementos() const {
    return vector_elementos.size();
}

