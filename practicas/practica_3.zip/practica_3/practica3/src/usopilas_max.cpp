/**
 * @file usopilas_max.cpp
 * @author David Mu�oz S�nchez
 * @author Juan Manuel Rodr�guez G�mez
 */


#include <iostream>
#include <pila_max.h>

using namespace std;

/**
 * @brief Sobrecarga del operador de salida, muestra por pantalla el struct "elemento"
 * @param os Flujo de salida
 * @param elem Elemento a mostrar
 * @return Flujo de salida "os"
*/
std::ostream& operator<<(std::ostream& os, elemento elem) {

    os << "\n   " << elem.ele << "\t   " << elem.maximo;
    return os;
}

int main() {

    Pila_max p;
    int i;

    for(i = 10; i >= 0; i--)
        p.poner(i);

    while( !p.vacia() ) {
        elemento x = p.tope();
        cout << x << endl;
        p.quitar();
    }

    return 0;
}
