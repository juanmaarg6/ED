/**
 * @file pila_max_cola.cpp
 * @author David Mu�oz S�nchez
 * @author Juan Manuel Rodr�guez G�mez
 */

#include "pila_max_cola.h"

using namespace std;

Pila_max_Cola::Pila_max_Cola() {
}

Pila_max_Cola::Pila_max_Cola(const Pila_max_Cola& p)
              : cola(p.cola) {
}


Pila_max_Cola& Pila_max_Cola::operator=(const Pila_max_Cola& p) {
}

Pila_max_Cola::~Pila_max_Cola() {
}

bool Pila_max_Cola::vacia() const {
    return cola.vacia();
}

elemento& Pila_max_Cola::tope() {
    return cola.frente();
}

const elemento& Pila_max_Cola::tope() const {
    return cola.frente();
}

void Pila_max_Cola::poner(int elem) {

    Cola<elemento> cola_auxiliar;
    elemento x = {elem, elem};

    if( !vacia() )
        if(cola.frente().maximo > elem)
            x.maximo = cola.frente().maximo;

    cola_auxiliar.poner(x);

    while( !vacia() ) {
        cola_auxiliar.poner(cola.frente());
        quitar();
    }

    cola = cola_auxiliar;
}
     
void Pila_max_Cola::quitar() {
   if( !vacia() )
       cola.quitar(); 
}

int Pila_max_Cola::num_elementos() const {
    return cola.num_elementos();
}
