var searchData=
[
  ['frente',['frente',['../classCola.html#a1df4ad2b50116ef22e77ad3f77b02d29',1,'Cola::frente()'],['../classCola.html#a79aa911410e9698d255cb00acee7b365',1,'Cola::frente() const ']]]
];
