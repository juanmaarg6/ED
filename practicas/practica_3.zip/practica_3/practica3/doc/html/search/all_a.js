var searchData=
[
  ['vacia',['vacia',['../classCola.html#a63d527f52e207cd6783f12df481ad175',1,'Cola::vacia()'],['../classPila__max__Cola.html#a599725c5cd24543705063c1a6dd64f08',1,'Pila_max_Cola::vacia()'],['../classPila__max__VD.html#a090a1920f597b6f807e09fb5a304aa28',1,'Pila_max_VD::vacia()']]]
];
