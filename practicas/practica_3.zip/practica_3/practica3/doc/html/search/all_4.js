var searchData=
[
  ['num_5felementos',['num_elementos',['../classCola.html#aa8654a248be63133bacdc2e0e102f814',1,'Cola::num_elementos()'],['../classPila__max__Cola.html#a59b67b4e129b90865683783a17db7f5f',1,'Pila_max_Cola::num_elementos()'],['../classPila__max__VD.html#a07b83a3c0b6b40eaf994b3658046f9a4',1,'Pila_max_VD::num_elementos()']]]
];
