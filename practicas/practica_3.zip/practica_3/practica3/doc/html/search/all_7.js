var searchData=
[
  ['quitar',['quitar',['../classCola.html#a320766ddc7020424052c99e5c82a105d',1,'Cola::quitar()'],['../classPila__max__Cola.html#a19fa85fcff18310b4d112ce9205a0e43',1,'Pila_max_Cola::quitar()'],['../classPila__max__VD.html#ae5fbb62729fc80c188b5f6ad7f66fdb2',1,'Pila_max_VD::quitar()']]]
];
