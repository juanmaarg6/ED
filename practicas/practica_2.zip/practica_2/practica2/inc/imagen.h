/**
 * @file imagen.h
 * @author Juan Manuel Rodríguez Gómez
 */

#ifndef IMAGEN_H
#define IMAGEN_H

#include <iostream>
#include <cassert>
#include "imagenES.h"

typedef unsigned char byte;

/**
 * @class Imagen
 * @brief Clase usada para representar una imagen digital en niveles de gris.
*/
class Imagen {
    
    private:
        
        int filas;          /**< Número de filas de la imagen */
        int columnas;       /**< Número de columnas de la imagen */
        byte **imagen;      /**< Imagen (Matriz Dinámica de 2D) */
        
        
		/**
		 * @brief Reserva memoria y, si es necesario, libera la existente
		 * @param f Filas a reservar
		 * @param c Columnas a reservar
		 */
		void reservarMemoria(int f, int c);
        
		/**
		 * @brief Libera la memoria reservada
		 */
		void liberarMemoria();
			
		/**
		 * @brief Copia los datos de un objeto Imagen en otro
		 * @param img Imagen cuyos datos se copian
		 */
		void copiar(const Imagen& img);
    
    public:
        
		/**
		 * @brief Constructor por defecto
		 */
		Imagen();
        
		/**
		 * @brief Constructor con parámetros
		 * @param f Número de filas
		 * @param c Número de columnas
		 */
		Imagen(int f, int c);
			
		/**
		 * @brief Constructor con parámetros
		 * @param f Número de filas
		 * @param c Número de columnas
		 * @param pixeles Vector 1D de píxeles
		 */
		Imagen(int f, int c, const byte *pixeles);

		/**
		 * @brief Constructor de copia
		 * @param img Imagen que se va a copiar
		 */
		Imagen(const Imagen& img);  
        
		/**
		 * @brief Destructor
		 */
		~Imagen(); 
		
		/**
		 * @brief Operador de asignación
		 * @param img Rvalue de la asignación
		 * @return this Lvalue de la asignación
		 */
		Imagen& operator=(const Imagen& img);
			
		/**
		 * @brief Devuelve el número de filas de la imagen
		 * @return Número de filas de la imagen
		 */
		int num_filas() const;
			
		/**
		 * @brief Devuelve el número de columnas de la imagen
		 * @return Número de columnas de la imagen
		 */
		int num_columnas() const;
        
    	/**
	 	 * @brief Asigna un valor a un píxel de la imagen
         * @param f Fila de la imagen
         * @param c Columna de la imagen
         * @param valor Valor a asignar en el píxel de la imagen
         * @pre 0 <= f < num_filas()
         * @pre 0 <= c < num_columnas()
         * @pre 0 <= valor <= 255
	 	 */
		void asigna_pixel(int f, int c, byte valor);
        
        /**
	     * @brief Consulta el valor de un píxel de la imagen
         * @param f Fila de la imagen
         * @param c Columna de la imagen
         * @pre 0 <= f < num_filas()
         * @pre 0 <= c < num_columnas()
		 * @return Valor de un píxel de la imagen
	 	*/
		byte valor_pixel(int f, int c) const;

		/**
	     * @brief Devuelve un vector 1D con los píxeles de la imagen
		 * @return Vector 1D con los píxeles de la imagen
	 	*/
		byte* flat();

		/**
 		 * @brief Devuelve el mínimo nivel de gris de la imagen
 		 * @return Mínimo nivel de gris de la imagen
 		 */
		byte min_nivel_gris();

		/**
 		 * @brief Devuelve el máximo nivel de gris de la imagen
 		 * @return Máximo nivel de gris de la imagen
 		 */
		byte max_nivel_gris();
};

#endif /* IMAGEN_H */

