/**
 * @file imagen.cpp
 * @author Juan Manuel Rodríguez Gómez
 */

#include <iostream>
#include <cassert>
#include "imagen.h"
#include "imagenES.h"

using namespace std;


void Imagen::reservarMemoria(int f, int c) {
    
    if(imagen != nullptr)
        liberarMemoria();
    
    filas = f;
    columnas = c;
    
    imagen = new byte*[f];
    for(int i = 0; i < f; i++)
        imagen[i] = new byte[c];
}

void Imagen::liberarMemoria() {
    
    if(imagen != nullptr){
        for(int i = 0; i < num_filas(); i++)
            delete[] imagen[i];

        delete[] imagen;
    }
}

void Imagen::copiar(const Imagen& img) {
    
    if(imagen != nullptr)
        liberarMemoria();
    
    reservarMemoria(img.num_filas(), img.num_columnas());

    for(int i = 0; i < img.num_filas(); i++)
        for(int j = 0; j < img.num_columnas(); j++)
            asigna_pixel(i, j, img.valor_pixel(i, j));
}

Imagen::Imagen() {
    
    imagen = nullptr;
    filas = 0;
    columnas = 0;
}

Imagen::Imagen(int f, int c) {
    
    imagen = nullptr;
    reservarMemoria(f, c);
}

Imagen::Imagen(int f, int c, const byte *pixeles) {
    
    imagen = nullptr;
    reservarMemoria(f, c);
    int indice_vector_pixeles = 0;

    for(int i = 0; i < f; i++)
        for(int j = 0; j < c; j++) {
            imagen[i][j] = pixeles[indice_vector_pixeles];
            indice_vector_pixeles++;
        }
}

Imagen::Imagen(const Imagen& img) {
    
    imagen = nullptr;
    copiar(img);
}

Imagen::~Imagen() {
    
    liberarMemoria();
}

Imagen& Imagen::operator=(const Imagen& img) {
    
    if (this != &img)
        copiar(img);

    return *this;
}

int Imagen::num_filas() const {
    
    return filas;
}

int Imagen::num_columnas() const {
    
    return columnas;
}

void Imagen::asigna_pixel(int f, int c, byte valor) {
    
    assert(f >= 0 && f < num_filas());
    assert(c >= 0 && c < num_columnas());
    
    imagen[f][c] = valor;
}

byte Imagen::valor_pixel(int f, int c) const {
    
    assert(f >= 0 && f < num_filas());
    assert(c >= 0 && c < num_columnas());
    
    return imagen[f][c];
}

byte* Imagen::flat() {
    
    byte *vector_img = new byte[filas*columnas];
    int indice_vector_pixeles = 0;

    for(int i = 0; i < filas; i++)
        for(int j = 0; j < columnas; j++) {
            vector_img[indice_vector_pixeles] = imagen[i][j];
            indice_vector_pixeles++;
        }

    return vector_img;
}

byte Imagen::min_nivel_gris() {

    byte valor_min_nivel_gris = valor_pixel(0, 0);

    for(int i = 0; i < filas; i++)
        for(int j = 0; j < columnas; j++)
            if( valor_pixel(i, j) < valor_min_nivel_gris )
                valor_min_nivel_gris = valor_pixel(i, j);

    return valor_min_nivel_gris;
}

byte Imagen::max_nivel_gris() {

    byte valor_max_nivel_gris = valor_pixel(0, 0);

    for(int i = 0; i < filas; i++)
        for(int j = 0; j < columnas; j++)
            if( valor_pixel(i, j) > valor_max_nivel_gris )
                valor_max_nivel_gris = valor_pixel(i, j);
                
    return valor_max_nivel_gris;
}