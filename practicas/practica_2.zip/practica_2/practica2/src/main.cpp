/**
 * @file main.cpp
 * @author Juan Manuel Rodríguez Gómez
 */

#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <string>
#include <sstream>
#include "imagenES.h"
#include "imagen.h"

using namespace std;

/**
 * @brief Lee una imagen, la umbraliza y el resultado lo guarda en un fichero
 * @param fichE Nombre del fichero que contiene la imagen original
 * @param fichS Nombre del fichero que contendrá el resultado de la transformación
 * @param T_1 Valor inferior del intervalo de umbralización
 * @param T_2 Valor superior del intervalo de umbralización
 * @pre T_1 < T_2
 * @return True (1) si el resultado se guarda en un fichero correctamente y False (0) si no
 */
bool umbralizar(const char *fichE, const char* fichS, const int T_1, const int T_2) {

    assert(T_1 < T_2);

    byte *vector_img_umbralizada;
    int n_filas, n_columnas;
    bool comprobacion_escritura;
    
    byte *vector_img = LeerImagenPGM(fichE, n_filas, n_columnas);

    Imagen imagen_inicial(n_filas, n_columnas, vector_img);
    Imagen imagen_umbralizada(n_filas, n_columnas);
    byte pixel;

    for(int i = 0; i < imagen_inicial.num_filas(); i++)
        for(int j = 0; j < imagen_inicial.num_columnas(); j++) {

            pixel = imagen_inicial.valor_pixel(i, j);

            if( (pixel <= T_1) || (pixel >= T_2) )
                imagen_umbralizada.asigna_pixel(i, j, 255);
            else
                imagen_umbralizada.asigna_pixel(i, j, pixel); 
        }

    vector_img_umbralizada = imagen_umbralizada.flat();

    if( EscribirImagenPGM(fichS, vector_img_umbralizada, imagen_umbralizada.num_filas(), imagen_umbralizada.num_columnas()) )
        comprobacion_escritura = true;
    else
        comprobacion_escritura = false;

    return comprobacion_escritura;
}

/**
 * @brief Realiza zoom a una porción de la imagen
 * @param fichE Nombre del fichero que contiene la imagen original
 * @param fichS Nombre del fichero donde se guardará el icono
 * @param x_1 Coordenada x de la esquina superior izquierda de la porción de la imagen a la que se le hará zoom
 * @param y_1 Coordenada y de la esquina superior izquierda de la porción de la imagen a la que se le hará zoom
 * @param x_2 Coordenada x de la esquina inferior derecha de la porción de la imagen a la que se le hará zoom
 * @param y_2 Coordenada y de la esquina inferior derecha de la porción de la imagen a la que se le hará zoom
 * @pre x_1 < x_2
 * @pre y_1 < y_2
 * @return True (1) si el resultado se guarda en un fichero correctamente y False (0) si no
 */
bool zoom(const char *fichE, const char* fichS, const int x_1, const int y_1, const int x_2, const int y_2) {

    assert(x_1 >= 0 && y_1 >= 0 && x_2 >= 0 && y_2 >= 0);
    assert(x_1 < x_2 && y_1 < y_2);

    byte *vector_subimg_zoom;
    int n_filas, n_columnas;
    bool comprobacion_escritura;
    
    byte *vector_img = LeerImagenPGM(fichE, n_filas, n_columnas);

    Imagen imagen_inicial(n_filas, n_columnas, vector_img);

    assert(x_1 < n_columnas && y_1 < n_filas && x_2 < n_columnas && y_2 < n_filas);

    int n_filas_zoom = 2 * (y_2 - y_1) - 1;
    int n_columnas_zoom = 2 * (x_2 - x_1) - 1;
    Imagen subimagen_zoom(n_filas_zoom, n_columnas_zoom);

    byte interpolacion_fila, interpolacion_columna;

    for(int i = 0; i < subimagen_zoom.num_filas(); i+=2)
        for(int j = 0; j < subimagen_zoom.num_columnas(); j+=2)
            subimagen_zoom.asigna_pixel(i, j, imagen_inicial.valor_pixel(x_1 + (i / 2), y_1 + (j / 2)));

    for(int i = 1; i < subimagen_zoom.num_filas(); i+=2)
        for(int j = 0; j < subimagen_zoom.num_columnas(); j++) {
            
            interpolacion_fila = ceil( ( subimagen_zoom.valor_pixel(i-1, j) + subimagen_zoom.valor_pixel(i+1, j) ) / 2.0);
            subimagen_zoom.asigna_pixel(i, j, interpolacion_fila);
        }

    for(int i = 0; i < subimagen_zoom.num_filas(); i++)
        for(int j = 1; j < subimagen_zoom.num_columnas(); j+=2) {
            
            interpolacion_columna = ceil( ( subimagen_zoom.valor_pixel(i, j-1) + subimagen_zoom.valor_pixel(i, j+1) ) / 2.0);
            subimagen_zoom.asigna_pixel(i, j, interpolacion_columna);
        }

    vector_subimg_zoom = subimagen_zoom.flat();

    if( EscribirImagenPGM(fichS, vector_subimg_zoom, subimagen_zoom.num_filas(), subimagen_zoom.num_columnas()) )
        comprobacion_escritura = true;
    else
        comprobacion_escritura = false;

    return comprobacion_escritura;
}

/**
 * @brief Aumenta el contraste de una imagen
 * @param fichE Nombre del fichero que contiene la imagen original
 * @param fichS Nombre del fichero que contendrá el resultado de la transformación
 * @param min Extremo inferior del nuevo rango de niveles de gris de la imagen
 * @param max Extremo superior del nuevo rango de niveles de gris de la imagen
 * @pre min < max
 * @return True (1) si el resultado se guarda en un fichero correctamente y False (0) si no
 */
bool aumentar_contraste(const char *fichE, const char *fichS, const int min, const int max) {

    assert(min < max);

    byte *vector_img_contrastada;
    int n_filas, n_columnas;
    bool comprobacion_escritura;
    
    byte *vector_img = LeerImagenPGM(fichE, n_filas, n_columnas);

    Imagen imagen_inicial(n_filas, n_columnas, vector_img);
    Imagen imagen_contrastada(n_filas, n_columnas);

    byte pixel, pixel_contrastado;
    double valor;
    int redondeo_valor;
    const int a = imagen_inicial.min_nivel_gris();
    const int b = imagen_inicial.max_nivel_gris();

    const double cociente = double(max - min) / (b - a);
    
    for(int i = 0; i < imagen_inicial.num_filas(); i++)
        for(int j = 0; j < imagen_inicial.num_columnas(); j++) {

            pixel = imagen_inicial.valor_pixel(i, j);

            valor = min + (cociente * (pixel - a));
            
            const int valor_entero = int(valor);

            if( (valor - valor_entero) >= 0.5)
                redondeo_valor = ceil(valor);
            else
                redondeo_valor = floor(valor);

            pixel_contrastado = redondeo_valor;

            imagen_contrastada.asigna_pixel(i, j, pixel_contrastado);
        }

    vector_img_contrastada = imagen_contrastada.flat();

    if( EscribirImagenPGM(fichS, vector_img_contrastada, imagen_contrastada.num_filas(), imagen_contrastada.num_columnas()) )
        comprobacion_escritura = true;
    else
        comprobacion_escritura = false;

    return comprobacion_escritura;
}

/**
 * @brief Convierte un dato de tipo entero a un dato de tipo string
 * @param valor Dato de tipo entero que queremos convertir
 * @return Dato de tipo string 
 */
string to_string(int valor) {

    stringstream stream;
    stream << valor;
    return stream.str();
}

/**
 * @brief Realiza una transición suave de una imagen a otra (acción conocida como morphing)
 * @param fichO Nombre del fichero que contiene la imagen inicial
 * @param fichR Nombre del fichero que coontiene la a la que se pretende llegar
 * @param iteraciones Número de iteraciones a realizar en el morphing
 * @return True (1) si se realiza el morphing correctamente y False (0) si no
 */
bool morphing(const char *fichO, const char *fichR, int iteraciones) {

    byte *vector_img_original, *vector_img_resultado, *vector_fotograma;
    int n_filas_original, n_columnas_original;
    int n_filas_resultado, n_columnas_resultado;
    bool comprobacion_escritura;
    
    vector_img_original = LeerImagenPGM(fichO, n_filas_original, n_columnas_original);
    vector_img_resultado = LeerImagenPGM(fichR, n_filas_resultado, n_columnas_resultado);

    Imagen imagen_inicial(n_filas_original, n_columnas_original, vector_img_original);
    Imagen imagen_resultado(n_filas_resultado, n_columnas_resultado, vector_img_resultado);

    assert(imagen_inicial.num_filas() == imagen_resultado.num_filas() &&
           imagen_inicial.num_columnas() == imagen_resultado.num_columnas());

    Imagen fotograma(imagen_inicial);

    for(int i = 0; i < iteraciones; i++) {
        for(int j = 0; j < fotograma.num_filas(); j++) {
            for(int k = 0; k < fotograma.num_columnas(); k++) {
                double paso = (1.0 * i) / iteraciones;
                fotograma.asigna_pixel(j, k, 
                                       paso * imagen_inicial.valor_pixel(j, k) + (1 - paso) * imagen_resultado.valor_pixel(j, k));
            }
        }
        
        std::string nombre = "figures/paso" + to_string(i) + ".pgm";
        const char *fichI = nombre.c_str();
        vector_fotograma = fotograma.flat();

        if( EscribirImagenPGM(fichI, vector_fotograma, fotograma.num_filas(), fotograma.num_columnas()) )
            comprobacion_escritura = true;
        else
            comprobacion_escritura = false;
    }

    return comprobacion_escritura;
}

/**
 * @brief Función principal
 */
int main (int argc, char *argv[]){

    char *origen, *resultado;

    if (argc != 3){
        cerr << endl << "Error: Numero incorrecto de parametros.\n";
        cerr << "Uso: main <FichImagenOriginal> <FichImagenResultante>\n";
        exit (1);
    }

    origen  = argv[1];
    resultado = argv[2];

    cout << endl;
    cout << "Fichero origen: " << origen << endl;
    cout << "Fichero resultado: " << resultado << endl << endl;    

    char opcion;

    cout << "Menu de opciones: " << endl << endl;
    cout << "\tA) Umbralizar la imagen usando escala de grises" << endl;
    cout << "\tB) Zoom de una porcion de la imagen" << endl;
    cout << "\tC) Aumento de contraste de la imagen mediante una transformacion lineal" << endl;
    cout << "\tD) Simulacion de un morphing" << endl << endl;

    cout << "Elija una opcion (A, B, C o D): ";
    cin >> opcion;

    opcion = toupper(opcion);

    switch (opcion) {
        case 'A':

            if ( umbralizar(origen, resultado, 30, 100) ) {
                cout << endl << "Imagen umbralizada correctamente" << endl;
                cout << "El resultado se ha guardado en " << resultado << endl;
            }
            else {
                cerr << "Error: No pudo umbralizarse la imagen." << endl;
                cerr << "Terminando la ejecucion del programa." << endl;
                exit (2);            
            }
            
            break;

        case 'B':

            if ( zoom(origen, resultado, 100,  100, 200, 200) ) {
                cout << endl << "Zoom a la imagen realizado correctamente" << endl;
                cout << "El resultado se ha guardado en " << resultado << endl;
            }
            else {
                cerr << "Error: No pudo hacerse zoom la imagen." << endl;
                cerr << "Terminando la ejecucion del programa." << endl;
                exit (2);            
            }
            
            break;

        case 'C':

            if ( aumentar_contraste(origen, resultado, 30, 100) ) {
                cout << endl << "Imagen contrastada correctamente" << endl;
                cout << "El resultado se ha guardado en " << resultado << endl;
            }
            else {
                cerr << "Error: No pudo contrastarse la imagen." << endl;
                cerr << "Terminando la ejecucion del programa." << endl;
                exit (2);            
            }
            
            break;

        case 'D':

            if ( morphing(origen, resultado, 10) )
                cout << endl << "Morphing realizado correctamente" << endl;
            else {
                cerr << "Error: No pudo realizarse el morphing." << endl;
                cerr << "Terminando la ejecucion del programa." << endl;
                exit (2);            
            }

            break;
        
        default:

            break;
    }
    
    return 0;
}
