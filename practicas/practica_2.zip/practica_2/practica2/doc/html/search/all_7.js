var searchData=
[
  ['operator_3d',['operator=',['../classImagen.html#a43d10ec74966d22e5477f686462802dc',1,'Imagen']]]
];
