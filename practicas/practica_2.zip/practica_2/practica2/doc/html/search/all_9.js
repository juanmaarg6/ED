var searchData=
[
  ['umbralizar',['umbralizar',['../main_8cpp.html#ae22034814dcd68882b04981f6512fa50',1,'main.cpp']]]
];
