var searchData=
[
  ['escribirimagenpgm',['EscribirImagenPGM',['../imagenES_8h.html#a4b649cc272f02649563791d5ed75b557',1,'EscribirImagenPGM(const char *nombre, const unsigned char *datos, const int fils, const int cols):&#160;imagenES.cpp'],['../imagenES_8cpp.html#a4b649cc272f02649563791d5ed75b557',1,'EscribirImagenPGM(const char *nombre, const unsigned char *datos, const int fils, const int cols):&#160;imagenES.cpp']]],
  ['escribirimagenppm',['EscribirImagenPPM',['../imagenES_8h.html#ae149be8653b9f8c7321ac40577e7518c',1,'EscribirImagenPPM(const char *nombre, const unsigned char *datos, const int fils, const int cols):&#160;imagenES.cpp'],['../imagenES_8cpp.html#ae149be8653b9f8c7321ac40577e7518c',1,'EscribirImagenPPM(const char *nombre, const unsigned char *datos, const int fils, const int cols):&#160;imagenES.cpp']]]
];
