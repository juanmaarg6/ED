var searchData=
[
  ['imagen',['Imagen',['../classImagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../classImagen.html#a4b397c4a3dc0794cab351f96dc9390fd',1,'Imagen::Imagen(int f, int c)'],['../classImagen.html#aa2f5aabdb30b49ec11487c101c591381',1,'Imagen::Imagen(int f, int c, const byte *pixeles)'],['../classImagen.html#aebf637b27aa4c1bcefbec6b61f28a1b2',1,'Imagen::Imagen(const Imagen &amp;img)']]]
];
