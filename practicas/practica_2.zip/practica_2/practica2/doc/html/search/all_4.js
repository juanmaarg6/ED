var searchData=
[
  ['leerimagenpgm',['LeerImagenPGM',['../imagenES_8h.html#a03340a1e1e4a88385c972bb4af463649',1,'LeerImagenPGM(const char *nombre, int &amp;fils, int &amp;cols):&#160;imagenES.cpp'],['../imagenES_8cpp.html#a03340a1e1e4a88385c972bb4af463649',1,'LeerImagenPGM(const char *nombre, int &amp;fils, int &amp;cols):&#160;imagenES.cpp']]],
  ['leerimagenppm',['LeerImagenPPM',['../imagenES_8h.html#a05aea20533de5bbd02789f76aafbb99b',1,'LeerImagenPPM(const char *nombre, int &amp;fils, int &amp;cols):&#160;imagenES.cpp'],['../imagenES_8cpp.html#a05aea20533de5bbd02789f76aafbb99b',1,'LeerImagenPPM(const char *nombre, int &amp;fils, int &amp;cols):&#160;imagenES.cpp']]],
  ['leertipoimagen',['LeerTipoImagen',['../imagenES_8h.html#acaa5fb277940aceed29f86c093a3d89c',1,'LeerTipoImagen(const char *nombre):&#160;imagenES.cpp'],['../imagenES_8cpp.html#acaa5fb277940aceed29f86c093a3d89c',1,'LeerTipoImagen(const char *nombre):&#160;imagenES.cpp']]]
];
