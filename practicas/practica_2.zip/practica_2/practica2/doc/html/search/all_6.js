var searchData=
[
  ['num_5fcolumnas',['num_columnas',['../classImagen.html#a29f1a1d6a8b9afb41036d76e9d64d4eb',1,'Imagen']]],
  ['num_5ffilas',['num_filas',['../classImagen.html#a56e4e6b003149ea2bc9dfecf09b22d5a',1,'Imagen']]]
];
