var searchData=
[
  ['tipoimagen',['TipoImagen',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522ed',1,'imagenES.h']]],
  ['to_5fstring',['to_string',['../main_8cpp.html#acb46d2c772615c9874b757dfaff2e6c8',1,'main.cpp']]]
];
