var searchData=
[
  ['main',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['max_5fnivel_5fgris',['max_nivel_gris',['../classImagen.html#a66c91d2ebb9c8198a7b133907b1a3415',1,'Imagen']]],
  ['min_5fnivel_5fgris',['min_nivel_gris',['../classImagen.html#a7987a7ff3f66b0fdee74f49e41f9f514',1,'Imagen']]],
  ['morphing',['morphing',['../main_8cpp.html#a21552a4c7a9e0b0c95d46742859d0bb5',1,'main.cpp']]]
];
