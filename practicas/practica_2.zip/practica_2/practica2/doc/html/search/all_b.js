var searchData=
[
  ['zoom',['zoom',['../main_8cpp.html#a37f0a994f4735c656e738571b66de675',1,'main.cpp']]]
];
