var searchData=
[
  ['valor_5fpixel',['valor_pixel',['../classImagen.html#a0c3670dd527c733a10690d479d4605f2',1,'Imagen']]]
];
