var searchData=
[
  ['asigna_5fpixel',['asigna_pixel',['../classImagen.html#afc6a4bab37be04985b18b7d054b020a9',1,'Imagen']]],
  ['aumentar_5fcontraste',['aumentar_contraste',['../main_8cpp.html#a7cd9a064f736aa5e9c4fd71694e18920',1,'main.cpp']]]
];
