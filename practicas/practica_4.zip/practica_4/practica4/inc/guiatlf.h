/**
 * @file guiatlf.h
 * @author Juan Manuel Rodri­guez Gomez
 */

#ifndef _GUIA_TLF_H
#define _GUIA_TLF_H

#include <iostream>
#include <string>
#include <map>

using namespace std;

/**
 * @brief Operador de entrada. Lee un tipo de dato pair.
 * @param is Flujo de entrada.
 * @param d Pair a leer.
 * @return Flujo de entrada "is".
 */
inline istream & operator>>(istream &is,pair<string,string> &d);

/**
 * @class Guia_Tlf
 * @brief Clase creada para representar una guia telefonica, la cual no es mas que un map
 *        de strings.
 */
class Guia_Tlf {
	
	private:
		
		map<string,string> datos;		/**< Nombres y telefonos */
					     
	public:
		
		/**
		 * @brief Constructor por defecto.
		 */		
		Guia_Tlf() = default;
		
		/**
		 * @brief Constructor de copia.
		 * @param gt Guia telefonica a copiar.
		 */	
		Guia_Tlf(const Guia_Tlf &gt);
		
		/**
		 * @brief Destructor.
		 */	
		~Guia_Tlf() = default;
		
		/**
		 * @brief Operador de asignacion.
		 * @param gt Guia telefonica a asignar.
		 * @return this Referencia a la guia telefonica actual.
		 */	
		Guia_Tlf &operator=(const Guia_Tlf &gt) = default;

		/**
		 * @brief Accede a un elemento.
		 * @param nombre Nombre del elemento a acceder.
		 * @return Valor asociado a un nombre, es decir, el telefono.
		 */
		string &operator[](const string &nombre);
		    
		/**
		 * @brief Devuelve el telefono de un nombre dado.
		 * @param nombre Nombre del elemento a acceder.
		 * @return Valor asociado a un nombre, es decir, el telefono.
		 */
		string gettelefono(const string &nombre);
		     
		/**
		 * @brief Inserta un nuevo telefono.
		 * @param nombre Nombre clave del nuevo telefono.
		 * @param tlf Numero de telefono.
		 * @return Pair donde first apunta al nuevo elemento insertado y second es
		 *         un bool, el cual es True (1) si se ha insertado el nuevo telefono
		 *         y False (0) si no se ha insertado.
		 */
		pair<map<string,string>::iterator,bool> insert(string nombre, string tlf);
		    
		/**
		 * @brief Inserta un nuevo nombre y su telefono asociado.
		 * @param p Pair con el nombre y el telefono asociado.
		 * @return Pair donde first apunta al nuevo elemento insertado y second es 
		 *         un bool, el cual es True (1) si se ha insertado el nuevo elemento
		 *         y False (0) si no se ha insertado.
		 */
		pair<map<string,string>::iterator,bool> insert(pair<string,string> p);
		    
		/**
		 * @brief Borra un nombre.
		 * @param nombre Nombre a borrar.
		 * @note En caso de que fuese un multimap borraria todos los elementos con ese nombre.
		 */
		void borrar(const string &nombre);
		    
		/**
		 * @brief Borra un telefono.
		 * @param nombre Nombre a borrar.
		 * @param tlf Telefono a borrar asociado a un nombre.
		 * @note Esta funcion nos permite borrar solamente aquel que coincida en nombre y telefono.
		 * @note Con map siempre hay uno.  on multimap puede existir mas de uno.
		 */
		void borrar(const string &nombre, const string &tlf);
		
		/**
		 * @brief Devuelve el numero de elementos de la guia telefonica. 
		 * @return Numero de elementos de la guia telefonica. 
		 */
		int size() const;

		/**
		 * @brief Contabiliza cuantos telefonos tenemos asociados a un nombre.
		 * @param nombre Nombre sobre el que queremos consultar.
		 * @return Numero de telefonos asociados a un nombre.
		 * @note Al ser un map debe de ser 0 o 1. Si fuese un multimap podriamos tener mas de uno.
		 */
		unsigned int contabiliza(const string &nombre);

		/**
		 * @brief Limpia la guia telefonica.
		 */
		void clear();
		
		/**
		 * @brief Union de dos guias de telefonos.
		 * @param g Guia a unir.
		 * @return Nueva guia resultado de unir el objeto al que apunta this y g.
	     */
		Guia_Tlf operator+(const Guia_Tlf &g);
		    	      
		/**
		 * @brief Diferencia de guias de telefonos.
		 * @param g Guia a restar.
		 * @return Nueva guia resultado de la diferencia del objeto al que apunta this y g.
		*/
		Guia_Tlf operator-(const Guia_Tlf &g);
		
		/**
		 * @brief Realiza la interseccion de dos guias telefonicas.
		 * @param gt Guia telefonica a intersecar.
		 * @return Interseccion de dos guias telefonicas.
		 */	
		Guia_Tlf interseccion(const Guia_Tlf &gt);

		/**
		 * @brief Modifica el telefono asociado a un nombre.
		 * @param nombre Nombre a buscar en la guia telefonica.
		 * @param tlf Telefono a asignar asociado a un nombre. 
		 * @note Al ser un map debe de ser 0 o 1. Si fuese un multimap podriamos tener mas de uno.
		 */	
		void modificar_telefono(const string &nombre, const string &tlf);

		/**
		 * @brief Modifica el telefono asociado a un nombre.
		 * @param nombre Nombre a buscar en la guia telefonica.
		 * @param tlf_antiguo Telefono a modificar asociado a un nombre.
		 * @param tlf_nuevo Nuevo telefono asociado a un nombre que sustituira a tlf_antiguo.
		 * @note Se usa si tuvieramos un multimap, en el que podriamos tener mas de un telefono por nombre.
		 */	
		void modificar_telefono(const string &nombre, const string &tlf_antiguo, const string &tlf_nuevo);

		/**
		 * @brief Devuelve los telefonos de aquellos nombres que empiezan por un caracter dado.
		 * @param caracter Letra por la que empiezan los nombres cuyos telefonos queremos obtener.
		 * @return Guia Telefonica con los telefonos de todos los nombres que empiezan por un caracter dado.
		 */
		Guia_Tlf gettelefonos_por_letra(const char &caracter);

		/**
		 * @brief Devuelve los telefonos de aquellos nombres que esten dentro del rango nombre1 y nombre2.
		 * @param nombre1 Nombre a partir de la cual se empieza a devolver telefonos.
		 * @param nombre2 Nombre hasta el cual se termina de devolver telefonos.
		 * @return Guia Telefonica con los telefonos cuyos nombres esten dentro del rango nombre1 y nombre2.
		 */
		Guia_Tlf gettelefonos_rango(const string &nombre1, const string &nombre2);

		/**
 		 * @class iterator
 		 * @brief Clase iteradora (version no constante) creada para recorrer la guia telefonica.
 		 */
		class iterator {
  			
			private:
    			
				typename map<string,string>::iterator vit;

				/**
			 	 * @brief Constructor con parametros privado.
			 	 * @param vit Iterador de la clase map de la STL.
			 	 */
    			iterator(typename map<string,string>::iterator vit);

    			friend class Guia_Tlf;

			public:
				
				/**
		 		 * @brief Constructor por defecto.
		 		 */	
				iterator() = default;

				/**
		 		 * @brief Constructor de copia.
		 		 * @param It Iterador a copiar.
		 		 */	
				iterator(const iterator &it);

				/**
		 		 * @brief Operador de asignacion.
		 		 * @param it Iterador a asignar.
		 		 * @return this Referencia al iterador actual.
		 		 */	
				iterator &operator=(const iterator &it);

				/**
		 		 * @brief Operador de incremento prefijo.
		 		 * @return Referencia al iterador incrementado.
		 		 */
				iterator &operator++();

				/**
		 		 * @brief Operador de decremento prefijo.
		 		 * @return Referencia al iterador decrementado.
		 		 */
				iterator &operator--();

				/**
		 		 * @brief Operador de consulta.
		 		 * @return Elemento al que apunta el iterador.
		 		 */
				pair<const string,string> &operator*();

				/**
		 		 * @brief Operador de desigualdad.
				 * @param it Iterador a comparar. 
		 		 * @return True (1) si los iteradores no son iguales y False (0) si lo son.
		 		 */
				bool operator!=(const iterator &it) const;

				/**
		 		 * @brief Operador de igualdad.
				 * @param it Iterador a comparar. 
		 		 * @return True (1) si los iteradores son iguales y False (0) si no lo son.
		 		 */
				bool operator==(const iterator &it) const;
  		};

		/**
		 * @brief Devuelve un iterador que apunta al inicio de la guia telefonica.
		 * @return Iterador que apunta al inicio de la guia telefonica.
		 */
		iterator begin();

		/**
		 * @brief Devuelve un iterador que apunta al final de la guia telefonica.
		 * @return Iterador que apunta al final de la guia telefonica.
		 */
		iterator end();

		/**
 		 * @class const_iterator
 		 * @brief Clase iteradora (version constante) creada para recorrer la guia telefonica.
 		 */
		class const_iterator {
			
			private:

				typename map<string,string>::const_iterator vit;

				/**
			 	 * @brief Constructor con parametros privado.
			 	 * @param vit Iterador constante de la clase list de la STL.
			 	 */
				const_iterator(typename map<string,string>::const_iterator vit);

				friend class Guia_Tlf;

			public:
				
				/**
		 		 * @brief Constructor por defecto.
		 		 */
				const_iterator() = default;

				/**
		 		 * @brief Constructor de copia.
		 		 * @param It Iterador constante a copiar.
		 		 */	
				const_iterator(const const_iterator &it);

				/**
		 		 * @brief Operador de asignacion.
		 		 * @param it Iterador constante a asignar.
		 		 * @return this Referencia al iterador constante actual.
		 		 */	
				const_iterator &operator=(const const_iterator &it);

				/**
		 		 * @brief Operador de incremento prefijo.
		 		 * @return Referencia al iterador constante incrementado.
		 		 */
				const_iterator &operator++();

				/**
		 		 * @brief Operador de decremento prefijo.
		 		 * @return Referencia al iterador constante decrementado.
		 		 */
				const_iterator &operator--();

				/**
		 		 * @brief Operador de consulta.
		 		 * @return Elemento al que apunta el iterador constante.
		 		 */
				const pair<const string,string> &operator*() const;

				/**
		 		 * @brief Operador de desigualdad.
				 * @param it Iterador constante a comparar. 
		 		 * @return True (1) si los iteradores constante no son iguales y False (0) si lo son.
		 		 */
				bool operator!=(const const_iterator &it) const;

				/**
		 		 * @brief Operador de igualdad.
				 * @param it Iterador constante a comparar. 
		 		 * @return True (1) si los iteradores constantes son iguales y False (0) si no lo son.
		 		 */
				bool operator==(const const_iterator &it) const;
		};

		/**
		 * @brief Devuelve un iterador constante que apunta al inicio de la guia telefonica.
		 * @return Iterador constante que apunta al inicio de la guia telefonica.
		 */
		const_iterator cbegin() const;

		/**
		 * @brief Devuelve un iterador constante que apunta al final de la guia telefonica.
		 * @return Iterador constante que apunta al final de la guia telefonica.
		 */
		const_iterator cend() const;	

		friend ostream &operator<<(ostream &os, Guia_Tlf &g);
		friend istream &operator>>(istream &is, Guia_Tlf &g);
};

/**
 * @brief Operador de salida. Muestra por pantalla una guia telefonica.
 * @param os Flujo de salida.
 * @param g Guia telefonica a mostrar.
 * @return Flujo de salida "os".
 */  
ostream &operator<<(ostream &os, Guia_Tlf &g);

/**
 * @brief Operador de entrada. Lee una guia telefonica.
 * @param is Flujo de entrada.
 * @param g Guia telefonica a leer.
 * @return Flujo de entrada "is".
 */
istream &operator>>(istream &is, Guia_Tlf &g);

#endif /* _GUIA_TLF_H */
