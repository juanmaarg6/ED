/**
 * @file diccionario.h
 * @author Juan Manuel Rodri­guez Gomez
 */

#ifndef _DICCIONARIO_H
#define _DICCIONARIO_H

#include <iostream>
#include <string>
#include <list>

using namespace std;

/**
 * @brief Tipo de elemento que define el diccionario. T es el tipo de dato asociado a una clave que
 *        no se repite (DNI p.ej.) y list<U> es una lista de datos (string p.ej) asociados a la clave
 *        de tipo T. El diccionario está ordenado de menor a mayor clave.
 */
template <class T,class U>
struct data {

	T clave;				/**< Clave */
	list<U> info_asoci;		/**< Lista con la informacion asociada a la clave */
};
 
/**
 * @brief Operador de comparacion. Ordena 2 registros de acuerdo a la clave de tipo T.
 * @param d1 Elemento 1 de tipo data.
 * @param d2 Elemento 2 de tipo data.
 * @return True (1) si la clave de d1 es menor que la clave de d2 y False (0) si no lo es.
 * @note Puede usarse como un funtor.
 */
template <class T, class U>
bool operator<(const data<T,U> &d1, const data<T,U> &d2);

/**
 * @brief Comprueba si un elemento esta dentro de una lista.
 * @param l Lista donde se busca el elemento.
 * @param elem Elemento a buscar.
 * @return True (1) si se encuentra el elemento en la lista y False (0) si no.
 */
template <typename U>
bool ElementoEnLista(const list<U> & l, const U & elem);

/**
 * @class Diccionario
 * @brief Clase creada para representar un diccionario, el cual no es mas que una lista de
 *        elementos de tipo data.
 */
template <class T,class U>
class Diccionario {
	
	private:

		list<data<T,U> > datos;		/**< Lista de elementos de tipo data */

		/**
		 * @brief Copia un diccionario en otro.
		 * @param D Diccionario a copiar.
		 * @note La implementacion de este metodo puede hacerse usando iteradores
		 *       o directamente usando la funcion assign.
		 */
		void Copiar(const Diccionario<T,U> &D);
		
		/**
		 * @brief Elimina todos los elementos de un diccionario.
		 */
		void Borrar();			   
			       
	public:
	    
		/**
		 * @brief Constructor por defecto.
		 */		
		Diccionario();
		 
		/**
		 * @brief Constructor de copia.
		 * @param D Diccionario a copiar.
		 */	
		Diccionario(const Diccionario &D);
		 
		/**
		 * @brief Destructor.
		 */			
		~Diccionario() = default;
		
		/**
		 * @brief Operador de asignacion.
		 * @param D Diccionario a asignar.
		 * @return this Referencia al diccionario actual.
		 */		
		Diccionario<T,U> &operator=(const Diccionario<T,U> &D);
		
		/**
		 * @brief Busca la clave p en el diccionario.
		 * @param p Clave a buscar.
		 * @return True (1) si la clave p esta (ademas, en ese caso tambien 
		 *         devuelve un iterador a donde esta la clave) y False (0)
		 *         si no esta (ademas, en ese caso tambien devuelve end() y 
		 *         deja el iterador de salida apuntando al sitio donde deberia 
		 *         estar la clave)
		 */		
		bool Esta_Clave(const T &p, typename  list<data<T,U> >::iterator &it_out);
		
		/**
		 * @brief Inserta un nuevo registro en el diccionario.
		 * @param clave Clave del nuevo registro a insertar.
		 * @param info Lista del nuevo registro a insertar con toda 
		 *             la informacion asociada a la nueva clave.
		 * @note Si el diccionario no estuviera ordenado habria que usar
		 *       la funcion sort().
		 */	
		void Insertar(const T &clave, const list<U> &info);

		/**
		 * @brief Añade una nueva informacion asociada a una clave que esta en el diccionario.
		 * @param p Clave a buscar en el diccionario.
		 * @param s Nueva informacion, asociada a la clave que esta en el diccionario, que se inserta.
		 * @note La nueva informacion se inserta al final de la lista de informacion.
		 * @note Si no esta la clave, entonces la inserta y añade la informacion asociada a dicha clave. 
		 */	
		void AddSignificado_Palabra(const U &s, const T &p);
		 
		/**
		 * @brief Devuelve la informacion (una lista) asociada a una clave p.
		 * @param p Clave a buscar en el diccionario.
		 * @return Informacion (una lista) asociada a la clave p.
		 * @note Tambien podrian haberse definido:
		 *       data<T,U> &operator[](int pos) { return datos.at(pos); }
		 *       const data<T,U> &operator[](int pos) const { return datos.at(pos); }.
		 */	
		list<U> getInfo_Asoc(const T &p);   
		 
		/**
		 * @brief Devuelve el tamaño del diccionario.
		 * @return Tamaño del diccionario.
		 */	
		int size() const;
		
		/**
		 * @brief Elimina un elemento del diccionario por su clave.
		 * @param p Clave a buscar en el diccionario.
		 */	
		void BorrarPorClave(T p);

		/**
		 * @brief Realiza la union de dos diccionarios.
		 * @param D Diccionario a unir.
		 * @return Union de dos diccionarios.
		 * @note Si una clave se encuentra en los dos diccionarios, entonces se 
		 *       fusionaran las informaciones asociadas a dichas claves.
		 */	
		Diccionario<T,U> Union(const Diccionario<T,U> &D);

		/**
		 * @brief Devuelve los elementos del diccionario cuyas claves esten dentro del rango
		 *        de claves p_inicio y p_fin.
		 * @param p_inicio Clave a partir de la cual se empieza a devolver elementos.
		 * @param p_fin Clave hasta la cual se termina de devolver elementos.
		 * @return Elementos del diccionario cuyas claves estan dentro del rango
		 *         de claves p_inicio y p_fin.
		 */	
		Diccionario<T,U> SubDiccionario(const T &p_inicio, const T &p_fin);

		/**
		 * @brief Realiza la diferencia de dos diccionarios.
		 * @param D Diccionario a restar.
		 * @return Diferencia de dos diccionarios.
		 */
		Diccionario<T,U> Diferencia(const Diccionario<T,U> &D);

		/**
 		 * @class iterator
 		 * @brief Clase iteradora (version no constante) creada para recorrer el diccionario.
 		 */
		class iterator {
  			
			private:
    			
				typename list<data<T,U> >::iterator vit;

				/**
			 	 * @brief Constructor con parametros privado.
			 	 * @param vit Iterador de la clase list de la STL.
			 	 */
    			iterator(typename list<data<T,U> >::iterator vit);

    			friend class Diccionario<T,U>;

			public:
				
				/**
		 		 * @brief Constructor por defecto.
		 		 */	
				iterator() = default;

				/**
		 		 * @brief Constructor de copia.
		 		 * @param It Iterador a copiar.
		 		 */	
				iterator(const iterator &it);

				/**
		 		 * @brief Operador de asignacion.
		 		 * @param it Iterador a asignar.
		 		 * @return this Referencia al iterador actual.
		 		 */	
				iterator &operator=(const iterator &it);	

				/**
		 		 * @brief Operador de incremento prefijo.
		 		 * @return Referencia al iterador incrementado.
		 		 */
				iterator &operator++();

				/**
		 		 * @brief Operador de decremento prefijo.
		 		 * @return Referencia al iterador decrementado.
		 		 */
				iterator &operator--();

				/**
		 		 * @brief Operador de consulta.
		 		 * @return Elemento al que apunta el iterador.
		 		 */
				data<T,U> &operator*();

				/**
		 		 * @brief Operador de desigualdad.
				 * @param it Iterador a comparar. 
		 		 * @return True (1) si los iteradores no son iguales y False (0) si lo son.
		 		 */
				bool operator!=(const iterator &it) const;

				/**
		 		 * @brief Operador de igualdad.
				 * @param it Iterador a comparar. 
		 		 * @return True (1) si los iteradores son iguales y False (0) si no lo son.
		 		 */
				bool operator==(const iterator &it) const;
  		};

		/**
		 * @brief Devuelve un iterador que apunta al inicio del diccionario.
		 * @return Iterador que apunta al inicio del diccionario.
		 */
		iterator begin();

		/**
		 * @brief Devuelve un iterador que apunta al final del diccionario.
		 * @return Iterador que apunta al final del diccionario.
		 */
		iterator end();

		/**
 		 * @class const_iterator
 		 * @brief Clase iteradora (version constante) creada para recorrer el diccionario.
 		 */
		class const_iterator {
			
			private:

				typename list<data<T,U> >::const_iterator vit;

				/**
			 	 * @brief Constructor con parametros privado.
			 	 * @param vit Iterador constante de la clase list de la STL.
			 	 */
				const_iterator(typename list<data<T,U> >::const_iterator vit);

				friend class Diccionario<T, U>;

			public:
				
				/**
		 		 * @brief Constructor por defecto.
		 		 */	
				const_iterator() = default;

				/**
		 		 * @brief Constructor de copia.
		 		 * @param It Iterador constante a copiar.
		 		 */	
				const_iterator(const const_iterator &it);

				/**
		 		 * @brief Operador de asignacion.
		 		 * @param it Iterador constante a asignar.
		 		 * @return this Referencia al iterador constante actual.
		 		 */	
				const_iterator &operator=(const const_iterator &it);

				/**
		 		 * @brief Operador de incremento prefijo.
		 		 * @return Referencia al iterador constante incrementado.
		 		 */
				const_iterator &operator++();

				/**
		 		 * @brief Operador de decremento prefijo.
		 		 * @return Referencia al iterador constante decrementado.
		 		 */
				const_iterator &operator--();

				/**
		 		 * @brief Operador de consulta.
		 		 * @return Elemento al que apunta el iterador constante.
		 		 */
				const data<T,U> &operator*() const;

				/**
		 		 * @brief Operador de desigualdad.
				 * @param it Iterador constante a comparar. 
		 		 * @return True (1) si los iteradores constante no son iguales y False (0) si lo son.
		 		 */
				bool operator!=(const const_iterator &it) const;

				/**
		 		 * @brief Operador de igualdad.
				 * @param it Iterador constante a comparar. 
		 		 * @return True (1) si los iteradores constantes son iguales y False (0) si no lo son.
		 		 */
				bool operator==(const const_iterator &it) const;
		};

		/**
		 * @brief Devuelve un iterador constante que apunta al inicio del diccionario.
		 * @return Iterador constante que apunta al inicio del diccionario.
		 */
		const_iterator cbegin() const;

		/**
		 * @brief Devuelve un iterador constante que apunta al final del diccionario.
		 * @return Iterador constante que apunta al final del diccionario.
		 */
		const_iterator cend() const;	 	
};

#include "diccionario.cpp"

#endif /* _DICCIONARIO_H */
