/**
 * @file usodiccionario.cpp
 * @author Juan Manuel Rodri­guez Gomez
 */

#include <iostream>
#include <fstream>
#include "diccionario.h"

/**
 * @brief Operador de salida. Muestra por pantalla un diccionario.
 * @param os Flujo de salida.
 * @param D Diccionario a mostrar.
 * @return Flujo de salida "os".
 */
ostream &operator<<(ostream &os, const Diccionario<string,string> &D) {
	  
	Diccionario<string,string>::const_iterator it;
	
	for(it = D.cbegin(); it != D.cend(); ++it) {
	
		list<string>::const_iterator it_s;
		
		os << endl << (*it).clave << endl << " informacion asociada:" << endl;
		for(it_s = (*it).info_asoci.begin(); it_s != (*it).info_asoci.end(); ++it_s)
			os << "  " << (*it_s) << endl;

		os<<"**************************************"<<endl;
	}
	
	  return os;
}

/**
 * @brief Operador de entrada. Lee un diccionario.
 * @param is Flujo de entrada.
 * @param D Diccionario a leer.
 * @return Flujo de entrada "is".
 * @note El formato de la entrada es:
            - Numero de claves.
            - Clave-iesima.
            - Numero de informaciones asociadas.
            - Informacion asociada
 */
istream &operator>>(istream &is, Diccionario<string,string> &D) {

	int np;

	is >> np;
	is.ignore();

	Diccionario<string,string> Daux;

	for(int i = 0; i < np; i++) {

		string clave;

		getline(is, clave); 
		
		int ns;

		is >> ns; 
		is.ignore();
		
		list<string> laux;
		for(int j = 0; j < ns; j++) {

			string s;

			getline(is,s);
			
			// cout << "Significado leido " << s << endl;
			laux.insert(laux.end(), s);
		}

		Daux.Insertar(clave, laux);		      
	}

	D = Daux;

	return is;
}

/**
 * @brief Recorre la lista de informacion asociada a una clave y la imprime.
 * @param l Lista de informacion asociada a una clave.
 */
void EscribeSigni(const list<string> &l) {

	list<string>::const_iterator it_s;
	  
	for(it_s = l.begin(); it_s != l.end(); ++it_s)
		cout << *it_s << endl;
}	

/**
 * @brief Funcion principal.
 * @note Hay tres ficheros ejemplos de prueba: diccionario1.txt diccionario2.txt usodiccionario.txt
 * @note En el main leemos automaticamente los ficheros de prueba
 * @note Para ejecutar el programa en la terminal: ./bin/usodiccionario
 */
int main() {

	Diccionario<string,string> D_1;
	Diccionario<string,string> D_2;
	Diccionario<string,string> Sub_D;
	Diccionario<string,string> D_Union;
	Diccionario<string,string> D_Diferencia;

	string clave_1;
	string clave_2;
	string clave_a_borrar;

	ifstream fichero;

	// Diccionario 1

	cout << "Diccionario 1: " << endl;
	fichero.open("./datos/diccionario1.txt");
	fichero >> D_1;
	fichero.close();
	cout << D_1;

	// Diccionario 2

	cout << endl << endl << "Diccionario 2: " << endl;
	fichero.open("./datos/diccionario2.txt");
	fichero >> D_2;
	fichero.close();
	cout << D_2;
	
	// Union de Diccionario 1 y Diccionario 2

	D_Union = D_1.Union(D_2);

	cout << endl << endl;
	cout << "Union de Diccionario 1 y Diccionario 2: " << endl;
	cout << D_Union;
	
	// Diferencia de Diccionario 1 y Diccionario 2 (Diccionario 1 - Diccionario 2)

	D_Diferencia = D_1.Diferencia(D_2);
	
	cout << endl << endl;
	cout << "Diferencia de Diccionario 1 y Diccionario 2 (Diccionario 1 - Diccionario 2): " << endl;
	cout << D_Diferencia;

	// Claves que se encuentran dentro del rango [clave_1, clave_2] en la union de Diccionario 1 y Diccionario 2

	fichero.open("./datos/usodiccionario.txt");

	cout << endl << endl;
	cout << "Introduzca la primera clave del rango a buscar en la Union de Diccionario 1 y Diccionario 2: ";
	fichero >> clave_1;
	
	cout << "Introduzca la ultima clave del rango a buscar en la Union de Diccionario 1 y Diccionario 2: ";
	fichero >> clave_2;
	
	Sub_D = D_Union.SubDiccionario(clave_1, clave_2);

	cout << "Claves en el rango [" << clave_1 << "," << clave_2 << "] de la Union de Diccionario 1 y Diccionario 2 : " << endl;
	cout << Sub_D;

	// Borrar una clave de Diccionario 1

	cout << endl << endl;
	cout << "Introduzca la clave a borrar de Diccionario 1: ";
	fichero >> clave_a_borrar;

	fichero.close();

	D_1.BorrarPorClave(clave_a_borrar);

	cout << endl << "Diccionario 1 tras borrar la clave " << clave_a_borrar << ": " << endl;
	cout << D_1;

	/*
	Diccionario<string,string> D;

	cin >> D;
	cout << D;

	string a;

	cout << "Introduce una palabra" << endl;
	cin >> a;

	list<string> l = D.getInfo_Asoc(a);

	if(l.size() > 0)
		EscribeSigni(l);
	*/

	return 0;
}
