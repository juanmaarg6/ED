/**
 * @file usoguia.cpp
 * @author Juan Manuel Rodri­guez Gomez
 */

#include <iostream>
#include <fstream>
#include "guiatlf.h"

/**
 * @brief Funcion principal.
 * @note Hay tres ficheros ejemplos de prueba: guia1.txt guia2.txt usoguia.txt
 * @note En el main leemos automaticamente los ficheros de prueba
 * @note Para ejecutar el programa en la terminal: ./bin/usoguia
 */
int main() {

	Guia_Tlf G_1;
	Guia_Tlf G_2;
	Guia_Tlf G_Interseccion;
	Guia_Tlf Sub_G_Por_Caracter;
	Guia_Tlf Sub_G_Rango;

	char primera_letra_nombre;
	string nombre_1;
	string nombre_2;
	string nombre_a_modificar_tlf;
	string nuevo_telefono;

	ifstream fichero;
	
	// Guia Telefonica 1

	cout << "Guia Telefonica 1: " << endl << endl;
	fichero.open("./datos/guia1.txt");
	fichero >> G_1;
	fichero.close();
	cout << G_1;

	// Guia Telefonica 2

	cout << endl << endl << "Guia Telefonica 2: " << endl << endl;
	fichero.open("./datos/guia2.txt");
	fichero >> G_2;
	fichero.close();
	cout << G_2;

	// Interseccion de Guia Telefonica 1 y Guia Telefonica 2

	G_Interseccion = G_1.interseccion(G_2);

	cout << endl << endl;
	cout << "Interseccion de Guia Telefonica 1 y Guia Telefonica 2: " << endl << endl;
	cout << G_Interseccion;

	// Telefonos de aquellos nombres de la Guia Telefonica 1 que comienzan por la letra caracter

	fichero.open("./datos/usoguia.txt");
	
	cout << endl << endl;
	cout << "Introduzca la primera letra de aquellos nombres de la Guia Telefonica 1 cuyos telefonos quiere mostrar: ";
	fichero >> primera_letra_nombre;

	Sub_G_Por_Caracter =  G_1.gettelefonos_por_letra(primera_letra_nombre);

	cout << "Telefonos de aquellos nombres de la Guia Telefonica 1 que comienzan por la letra " << primera_letra_nombre << ": " << endl << endl;
	cout << Sub_G_Por_Caracter;

	// Telefonos de aquellos nombres de la Guia Telefonica 2 que se encuentran dentro del rango [nombre_1, nombre_2]

	fichero.ignore();
	cout << endl << endl;
	cout << "Introduzca el primer nombre del rango cuyo telefono desea buscar en la Guia Telefonica 2: ";
	getline(fichero, nombre_1);
	
	cout << "Introduzca el ultimo nombre del rango cuyo telefono desea buscar en la Guia Telefonica 2: ";
	getline(fichero, nombre_2);

	Sub_G_Rango = G_2.gettelefonos_rango(nombre_1, nombre_2);

	cout << "Telefonos de aquellos nombres en el rango [" << nombre_1 << "," << nombre_2 << "] de la Guia Telefonica 2 : " << endl << endl;
	cout << Sub_G_Rango;

	// Modificar el telefono asociado a un nombre de la Guia Telefonica 1

	cout << endl << endl;
	cout << "Introduzca el nombre de la Guia Telefonica 1 cuyo telefono desea modificar: ";
	getline(fichero, nombre_a_modificar_tlf);

	cout << "Introduzca el nuevo telefono de " << nombre_a_modificar_tlf << ": ";
	fichero >> nuevo_telefono;

	fichero.close();

	G_1.modificar_telefono(nombre_a_modificar_tlf, nuevo_telefono);
	
	cout << "Guia Telefonica 1 tras modificar el telefono de " << nombre_a_modificar_tlf << ": " << endl << endl;
	cout << G_1;

	/*
	Guia_Tlf g;
 	
	cout << "Introduce una guia" << endl;
 	cin >> g;
 	
	cout << "La guia insertada " << g << endl;
 	
	cin.clear();
	
	cout << "Dime un nombre sobre el que quieres obtener el telefono" << endl;
 	string n;
    while( getline(cin, n) ) {
			
			cout << "Buscando " << n << "...." << endl;

	   		string tlf = g.gettelefono(n);

	   		if(tlf == "") 
		    	cout << "No existe ese nombre en la guia" << endl;
	   		else 
	    		cout << "El telefono es " << tlf << endl;

	   		cout << "Dime un nombre sobre el que quieres obtener el telefono" << endl;
 	   	}	
 	
	   	cin.clear();
 
 	   	cout << "Dime el nombre que quieres borrar" << endl;
 
 	   	while( getline(cin, n) ) {
	   		g.borrar(n);
	   		cout << "Dime el nombre que quieres borrar" << endl;
 		}
 
 		cout << "Dime el nombre que quieres borrar" << endl;
 
 		while( getline(cin, n) ) {
	   		g.borrar(n);
	   		cout << "Ahora la guia es:" << endl;
	   		cout << g << endl;
	   		cout << "Dime el nombre que quieres borrar" << endl;
 		}

	cin.clear();

	Guia_Tlf otraguia;
 	
	cout << "Introduce otra guia" << endl;
 	cin >> otraguia; 
 
 	cin.clear();
 	
	Guia_Tlf un = g + otraguia;
 	Guia_Tlf dif = g - otraguia;

 	cout << "La union de las dos guias: " << endl << un << endl;
 	cout << "La diferencia de las dos guias:" << endl << dif << endl;
	*/
 
	return 0;
}
