/**
 * @file guiatlf.cpp
 * @author Juan Manuel Rodri­guez Gomez
 */

#include <guiatlf.h>

// Operador de lectura de pair

istream & operator>>(istream &is,pair<string,string> &d){
	  
	  getline(is,d.first,'\t');
	  getline(is,d.second);
	  return is;
}

// Guia_Tlf

Guia_Tlf::Guia_Tlf(const Guia_Tlf &gt) : datos(gt.datos.begin(), gt.datos.end()) { }

string &Guia_Tlf::operator[](const string &nombre) {
	
	return datos[nombre];
}

string Guia_Tlf::gettelefono(const string &nombre) {
	
	map<string,string>::iterator it = datos.find(nombre);
	
	if(it == datos.end()) 
		return string("");
	else 
		return it->second;
}

pair<map<string,string>::iterator,bool> Guia_Tlf::insert(string nombre, string tlf) {

	pair<string,string> p(nombre, tlf);
	pair< map<string,string>::iterator,bool> ret;

	ret = datos.insert(p); 
	
	return ret;     		
}

pair<map<string,string>::iterator,bool> Guia_Tlf::insert(pair<string,string> p) {
			
	pair<map<string,string>::iterator,bool> ret;

	ret = datos.insert(p); 
	
	return ret;     		
}

void Guia_Tlf::borrar(const string &nombre) {

	map<string,string>::iterator itlow = datos.lower_bound(nombre);		// Primero que tiene dicho nombre
	map<string,string>::iterator itupper = datos.upper_bound(nombre);	// Primero que ya no tiene dicho nombre
	
	datos.erase(itlow, itupper);		// Borramos todos aquellos que tienen dicho nombre
}

void Guia_Tlf::borrar(const string &nombre, const string &tlf) {
	
	map<string,string>::iterator itlow = datos.lower_bound(nombre);		// Primero que tiene dicho nombre
	map<string,string>::iterator itupper = datos.upper_bound(nombre);	// Primero que ya no tiene dicho nombre
	map<string,string>::iterator it;

	bool salir = false;
	
	for(it = itlow; it != itupper && !salir; ++it)
		if(it->second == tlf) {
			datos.erase(it);
			salir = true;
		}					   
}

int Guia_Tlf::size() const {

	return datos.size();
}

unsigned int Guia_Tlf::contabiliza(const string &nombre) {

	return datos.count(nombre);
}

void Guia_Tlf::clear() {
	datos.clear();
}	

Guia_Tlf Guia_Tlf::operator+(const Guia_Tlf &g) {
			
	Guia_Tlf aux(*this);
	map<string,string>::const_iterator it;

	for(it = g.datos.begin(); it != g.datos.end(); ++it)
		aux.insert(it->first, it->second);
			
	return aux;
}	 

Guia_Tlf Guia_Tlf::operator-(const Guia_Tlf &g) {
	
	Guia_Tlf aux(*this);
	map<string,string>::const_iterator it;

	for(it = g.datos.begin(); it != g.datos.end(); ++it)
		aux.borrar(it->first, it->second);
	
	return aux;
}

Guia_Tlf Guia_Tlf::interseccion(const Guia_Tlf &gt) {

	Guia_Tlf guia_interseccion(*this + gt);		// G_1 v G_2

	// G_1 ^ G_2 = (G_1 v G_2) \ ( (G_1 \ G_2) v (G_2 \ G_1) )
	guia_interseccion = guia_interseccion - ( ( guia_interseccion - gt ) + ( guia_interseccion - (*this) ) );

	return guia_interseccion;
}
	
void Guia_Tlf::modificar_telefono(const string &nombre, const string &tlf) {

	map<string,string>::iterator it = datos.lower_bound(nombre);		// Primero que tiene dicho nombre
    
    (*it).second = tlf;
}

void Guia_Tlf::modificar_telefono(const string &nombre, const string &tlf_antiguo, const string &tlf_nuevo) {

	map<string,string>::iterator itlow = datos.lower_bound(nombre);		// Primero que tiene dicho nombre
	map<string,string>::iterator itupper = datos.upper_bound(nombre);	// Primero que ya no tiene dicho nombre
	map<string,string>::iterator it;
    
	for(it = itlow; it != itupper; ++it)
        if( (*it).second == tlf_antiguo )
            (*it).second = tlf_nuevo;
}

Guia_Tlf Guia_Tlf::gettelefonos_por_letra(const char &caracter) {

	Guia_Tlf subguia;

	map<string,string>::iterator it_ini;
	map<string,string>::iterator it_fin;

	bool inicio_encontrado = false;
	bool final_encontrado = false;

	for(it_ini = datos.begin(); (it_ini != datos.end()) && !inicio_encontrado; ++it_ini)
		if( (*it_ini).first[0] == caracter ) {
			inicio_encontrado = true;
			it_ini--;
		}

	for(it_fin = it_ini; (it_fin != datos.end()) && !final_encontrado; ++it_fin)
		if( (*it_fin).first[0] != caracter ) {
			final_encontrado = true;
			it_fin--;
		}

	subguia.datos.insert(it_ini, it_fin);

	return subguia;
}

Guia_Tlf Guia_Tlf::gettelefonos_rango(const string &nombre1, const string &nombre2) {

    Guia_Tlf subguia;

    map<string,string>::iterator it_ini;
    map<string,string>::iterator it_fin;
    
	if (nombre1 < nombre2) {
        
		it_ini = datos.find(nombre1);
        it_fin = datos.find(nombre2);
		it_fin++;
        
		if(it_ini != datos.end())
            subguia.datos.insert(it_ini, it_fin);
	}

	return subguia;
}

// Guia_Tlf::iterator

Guia_Tlf::iterator::iterator(typename map<string,string>::iterator vit) {

	this->vit = vit;
}

Guia_Tlf::iterator::iterator(const iterator &it) {

	this->vit = it.vit;
}

Guia_Tlf::iterator &Guia_Tlf::iterator::operator=(const iterator &it) {

	if (this != &it)
    	vit = it.vit;

	return *this;
}

Guia_Tlf::iterator &Guia_Tlf::iterator::operator++() {

	vit++;

	return *this;
}

Guia_Tlf::iterator &Guia_Tlf::iterator::operator--() {

	vit--;

	return *this;
}

pair<const string,string> &Guia_Tlf::iterator::operator*() {

	return *vit;
}

bool Guia_Tlf::iterator::operator!=(const Guia_Tlf::iterator &it) const {

	return this->vit != it.vit;
}

bool Guia_Tlf::iterator::operator==(const Guia_Tlf::iterator &it) const {

	return this->vit == it.vit;
}

Guia_Tlf::iterator Guia_Tlf::begin() {

	return Guia_Tlf::iterator( datos.begin() );
}

Guia_Tlf::iterator Guia_Tlf::end() {
	
	return Guia_Tlf::iterator( datos.end() );
}

// Guia_Tlf::const_iterator

Guia_Tlf::const_iterator::const_iterator(typename  map<string,string>::const_iterator vit) {

	this->vit = vit;
}

Guia_Tlf::const_iterator::const_iterator(const const_iterator &it) {

	this->vit = it.vit;
}

Guia_Tlf::const_iterator &Guia_Tlf::const_iterator::operator=(const const_iterator &it) {

	if (this != &it)
    	vit = it.vit;

	return *this;
}

Guia_Tlf::const_iterator &Guia_Tlf::const_iterator::operator++() {

	vit++;

	return *this;
}

Guia_Tlf::const_iterator &Guia_Tlf::const_iterator::operator--() {

	vit--;

	return *this;
}

const pair<const string,string> &Guia_Tlf::const_iterator::operator*() const {

	return *vit;
}

bool Guia_Tlf::const_iterator::operator!=(const Guia_Tlf::const_iterator &it) const {

	return this->vit != it.vit;
}

bool Guia_Tlf::const_iterator::operator==(const Guia_Tlf::const_iterator &it) const {

	return this->vit == it.vit;
}

Guia_Tlf::const_iterator Guia_Tlf::cbegin() const {

	return Guia_Tlf::const_iterator( datos.begin() );
}

Guia_Tlf::const_iterator Guia_Tlf::cend() const {

	return Guia_Tlf::const_iterator( datos.end() );
}

// Operadores de lectura y escritura de guias telefonicas

ostream &operator<<(ostream &os, Guia_Tlf &g) {

	map<string,string>::iterator it;

	for(it = g.datos.begin(); it != g.datos.end(); ++it)
		os << it->first << "\t" << it->second << endl;

	return os;
}

istream &operator>>(istream &is, Guia_Tlf &g) {

	pair<string,string> p;
	Guia_Tlf aux;
	
	while(is >> p) {
		aux.insert(p);
	}

	g = aux;

	return is;
}
