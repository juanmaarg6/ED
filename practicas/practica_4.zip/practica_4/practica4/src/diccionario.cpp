/**
 * @file diccionario.cpp
 * @author Juan Manuel Rodri­guez Gomez
 */

// Operador de comparacion de elementos de tipo data

template <class T, class U>
bool operator<(const data<T,U> &d1, const data<T,U> &d2) {
	
	if(d1.clave < d2.clave)
		return true;
	
	return false;
}	

// Buscar un elemento en una lista
template <typename U>
bool ElementoEnLista(const list<U> & l, const U & elem) {

    typename list<U>::const_iterator it;

	bool encontrado = false;

	for(it = l.cbegin(); it != l.cend() && !encontrado; ++it)
		if( (*it) == elem )
			encontrado = true;

	return encontrado;
}

// Diccionario

template <class T, class U> 
void Diccionario<T,U>::Copiar(const Diccionario<T,U> &D) {
	
	/*
	typename list<data<T,U> >::const_iterator it_d;
	typename list<data<T,U> >::iterator it = this->datos.begin();
	*/
	
	datos.assign(D.datos.begin(), D.datos.end());
	/*
	for(it_d = D.datos.begin(); it_d != D.datos.end(); ++it_d, ++it)
		this->datos.insert(it, *it_d);
	*/
}

template <class T, class U> 
void Diccionario<T,U>::Borrar() {

	this->datos.erase(datos.begin(), datos.end());
}

template <class T, class U> 
Diccionario<T,U>::Diccionario() : datos(list<data<T,U> >()) { }

template <class T, class U> 
Diccionario<T,U>::Diccionario(const Diccionario &D) { 

	Copiar(D);
}

template <class T, class U> 
Diccionario<T,U> &Diccionario<T,U>::operator=(const Diccionario<T,U> &D) {
	
	if (this != &D) {
		Borrar();
		Copiar(D);
	}
	
	return *this;
}

template <class T, class U> 
bool Diccionario<T,U>::Esta_Clave(const T &p, typename list<data<T,U> >::iterator &it_out) {
			  
	if (datos.size() > 0) {
				    
		typename list<data<T,U> >::iterator it;
			      
		for(it = datos.begin(); it != datos.end(); ++it) {
			
			if( (*it).clave == p ) {
				it_out = it;
				return true;
			}
			else if( (*it).clave > p ) {
				it_out = it;
				return false;
			}	  
					   
		}
			      
		it_out = it;
		return false;
	}
	else {	
		it_out = datos.end();
		return false;
	}	    
}

template <class T, class U> 
void Diccionario<T,U>::Insertar(const T &clave, const list<U> &info) {
			
	typename list<data<T,U> >::iterator it;
			
	if( !Esta_Clave(clave, it) ) {

		data<T,U> p;

		p.clave = clave;
		p.info_asoci = info;
	
		datos.insert(it, p);				
	}	
}

template <class T, class U> 
void Diccionario<T,U>::AddSignificado_Palabra(const U &s, const T &p) {
	
	typename list<data<T,U> >::iterator it;
			
	if( !Esta_Clave(p, it) )
		datos.insert(it,p);	    
			
	(*it).info_asoci.insert( (*it).info_asoci.end(), s );
}

template <class T, class U> 
list<U> Diccionario<T,U>::getInfo_Asoc(const T &p) {
	
	typename list<data<T,U> >::iterator it;
			
	if( !Esta_Clave(p, it) )
		return list<U>();
	else
		return (*it).info_asoci;
}	

template <class T, class U> 
int Diccionario<T,U>::size() const {

	return datos.size();
}

template <class T, class U> 
void Diccionario<T,U>::BorrarPorClave(T p) {

    typename list<data<T,U> >::iterator it;

    if( Esta_Clave(p, it) )
        datos.erase(it);
}

template <class T, class U> 
Diccionario<T,U> Diccionario<T,U>::Union(const Diccionario<T,U> &D) {

    Diccionario diccionario_union(*this);

	typename list<data<T, U> >::const_iterator it;
	typename list<data<T, U> >::iterator it_aux;
	
	data<T,U> dato;

	for(it = D.datos.cbegin(); it != D.datos.cend(); ++it) {

		dato = *it;

		if( diccionario_union.Esta_Clave(dato.clave, it_aux) )
			(*it_aux).info_asoci.insert( (*it_aux).info_asoci.end(), (*it).info_asoci.begin(), (*it).info_asoci.end() );
		else
			diccionario_union.Insertar(dato.clave, dato.info_asoci);
	}

	return diccionario_union;
}

template <class T, class U> 
Diccionario<T,U> Diccionario<T,U>::SubDiccionario(const T &p_inicio, const T &p_fin) {

	Diccionario subdiccionario;

	typename list<data<T, U> >::iterator it_inicio;
	typename list<data<T, U> >::iterator it_fin;

	if( (p_inicio < p_fin) && Esta_Clave(p_inicio, it_inicio) && Esta_Clave(p_fin, it_fin) ) {
	
		typename list<data<T, U> >::iterator it;
	
		for(it = it_inicio; it != it_fin; ++it)
			subdiccionario.Insertar((*it).clave, (*it).info_asoci);
	}

	subdiccionario.Insertar((*it_fin).clave, (*it_fin).info_asoci);

    return subdiccionario;
}

template <class T, class U> 
Diccionario<T,U> Diccionario<T,U>::Diferencia(const Diccionario<T,U> &D) {

	Diccionario diccionario_diferencia(*this);

	typename list<data<T, U> >::const_iterator it;

	for (it = D.datos.begin(); it != D.datos.end(); ++it)
		diccionario_diferencia.BorrarPorClave( (*it).clave );

	return diccionario_diferencia;
}

// Diccionario::iterator

template <class T, class U>
Diccionario<T,U>::iterator::iterator(typename list<data<T,U> >::iterator vit) {

	this->vit = vit;
}

template <class T, class U>
Diccionario<T,U>::iterator::iterator(const iterator &it) {

	this->vit = it.vit;
}

template <class T, class U>
typename Diccionario<T,U>::iterator &Diccionario<T,U>::iterator::operator=(const iterator &it) {

	if (this != &it)
    		vit = it.vit;

	return *this;
}

template <class T, class U>
typename Diccionario<T,U>::iterator &Diccionario<T,U>::iterator::operator++() {

	vit++;

	return *this;
}

template <class T, class U>
typename Diccionario<T,U>::iterator &Diccionario<T,U>::iterator::operator--() {

	vit--;

	return *this;
}

template <class T, class U>
data<T,U> &Diccionario<T,U>::iterator::operator*() {

	return *vit;
}

template <class T, class U>
bool Diccionario<T,U>::iterator::operator!=(const Diccionario<T,U>::iterator &it) const {

	return this->vit != it.vit;
}

template <class T, class U>
bool Diccionario<T,U>::iterator::operator==(const Diccionario<T,U>::iterator &it) const {

	return this->vit == it.vit;
}

template <class T, class U>
typename Diccionario<T,U>::iterator Diccionario<T,U>::begin() {

	return Diccionario<T,U>::iterator( datos.begin() );
}

template <class T, class U>
typename Diccionario<T,U>::iterator Diccionario<T,U>::end() {
	
	return Diccionario<T,U>::iterator( datos.end() );
}

// Diccionario::const_iterator

template <class T, class U>
Diccionario<T,U>::const_iterator::const_iterator(typename list<data<T,U> >::const_iterator vit) {

	this->vit = vit;
}

template <class T, class U>
Diccionario<T,U>::const_iterator::const_iterator(const const_iterator &it) {

	this->vit = it.vit;
}

template <class T, class U>
typename Diccionario<T,U>::const_iterator &Diccionario<T,U>::const_iterator::operator=(const const_iterator &it) {

	if (this != &it)
    	vit = it.vit;

	return *this;
}

template <class T, class U>
typename Diccionario<T,U>::const_iterator &Diccionario<T,U>::const_iterator::operator++() {

	vit++;

	return *this;
}

template <class T, class U>
typename Diccionario<T,U>::const_iterator &Diccionario<T,U>::const_iterator::operator--() {

	vit--;

	return *this;
}

template <class T, class U>
const data<T, U> &Diccionario<T,U>::const_iterator::operator*() const {

	return *vit;
}

template <class T, class U>
bool Diccionario<T,U>::const_iterator::operator!=(const Diccionario<T,U>::const_iterator &it) const {

	return this->vit != it.vit;
}

template <class T, class U>
bool Diccionario<T,U>::const_iterator::operator==(const Diccionario<T,U>::const_iterator &it) const {

	return this->vit == it.vit;
}

template <class T, class U>
typename Diccionario<T,U>::const_iterator Diccionario<T,U>::cbegin() const {

	return Diccionario<T,U>::const_iterator( datos.cbegin() );
}

template <class T, class U>
typename Diccionario<T,U>::const_iterator Diccionario<T, U>::cend() const {

	return Diccionario<T,U>::const_iterator( datos.cend() );
}
