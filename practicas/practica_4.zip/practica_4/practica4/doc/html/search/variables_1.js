var searchData=
[
  ['info_5fasoci',['info_asoci',['../structdata.html#a8299bf6975cfaffbb2354a65881e16a2',1,'data']]]
];
