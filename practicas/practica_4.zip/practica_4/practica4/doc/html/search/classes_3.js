var searchData=
[
  ['iterator',['iterator',['../classDiccionario_1_1iterator.html',1,'Diccionario']]],
  ['iterator',['iterator',['../classGuia__Tlf_1_1iterator.html',1,'Guia_Tlf']]]
];
