var searchData=
[
  ['insert',['insert',['../classGuia__Tlf.html#add78a6fe5e8090ad6f71bbb160b70f77',1,'Guia_Tlf::insert(string nombre, string tlf)'],['../classGuia__Tlf.html#a4c4e4cc9540896434edd915296e56c87',1,'Guia_Tlf::insert(pair&lt; string, string &gt; p)']]],
  ['insertar',['Insertar',['../classDiccionario.html#af520b73907852cc8002260ddf9fb822c',1,'Diccionario']]],
  ['interseccion',['interseccion',['../classGuia__Tlf.html#a8ae36b095c68ea03ab25d82982e4ec29',1,'Guia_Tlf']]],
  ['iterator',['iterator',['../classDiccionario_1_1iterator.html#a22d83c21b9513571b3faf5103faf88dc',1,'Diccionario::iterator::iterator()=default'],['../classDiccionario_1_1iterator.html#aad7992e257dbf3011d658260417c2a3d',1,'Diccionario::iterator::iterator(const iterator &amp;it)'],['../classGuia__Tlf_1_1iterator.html#aca867c1a2039dcc442de943cf0cc4e5e',1,'Guia_Tlf::iterator::iterator()=default'],['../classGuia__Tlf_1_1iterator.html#a2b1e97dfe19077aae53ee973c824dbcd',1,'Guia_Tlf::iterator::iterator(const iterator &amp;it)']]]
];
