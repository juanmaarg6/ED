var searchData=
[
  ['const_5fiterator',['const_iterator',['../classDiccionario_1_1const__iterator.html',1,'Diccionario']]],
  ['const_5fiterator',['const_iterator',['../classGuia__Tlf_1_1const__iterator.html',1,'Guia_Tlf']]]
];
