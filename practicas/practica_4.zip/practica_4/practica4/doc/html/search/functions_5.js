var searchData=
[
  ['getinfo_5fasoc',['getInfo_Asoc',['../classDiccionario.html#a292817b0fda893a41cd9313b4c65cc61',1,'Diccionario']]],
  ['gettelefono',['gettelefono',['../classGuia__Tlf.html#a18593e3cf273db1a540cba69f87fd637',1,'Guia_Tlf']]],
  ['gettelefonos_5fpor_5fletra',['gettelefonos_por_letra',['../classGuia__Tlf.html#ae08d14b0acc85a2d8017002445fd16aa',1,'Guia_Tlf']]],
  ['gettelefonos_5frango',['gettelefonos_rango',['../classGuia__Tlf.html#add5b1798795ec566255a569bd95929b9',1,'Guia_Tlf']]],
  ['guia_5ftlf',['Guia_Tlf',['../classGuia__Tlf.html#af710ea22fb968c5e87a3694f62c6bb4d',1,'Guia_Tlf::Guia_Tlf()=default'],['../classGuia__Tlf.html#ac915549f0f8edb57861c6cc426ae6504',1,'Guia_Tlf::Guia_Tlf(const Guia_Tlf &amp;gt)']]]
];
