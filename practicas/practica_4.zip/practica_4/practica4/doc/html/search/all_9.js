var searchData=
[
  ['size',['size',['../classDiccionario.html#aee09a7283def9dc0d94b079887fff66e',1,'Diccionario::size()'],['../classGuia__Tlf.html#a081c98f65dce5a08a2e032446b6c4931',1,'Guia_Tlf::size()']]],
  ['subdiccionario',['SubDiccionario',['../classDiccionario.html#a6568627bd1838e46ca1b94144989cbbd',1,'Diccionario']]]
];
