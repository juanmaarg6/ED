var searchData=
[
  ['_7ediccionario',['~Diccionario',['../classDiccionario.html#ad2b64a73fc95c5cf4382fefcc18c2c62',1,'Diccionario']]],
  ['_7eguia_5ftlf',['~Guia_Tlf',['../classGuia__Tlf.html#a07c35f4b0ca6d51079b700dbd28f9b7e',1,'Guia_Tlf']]]
];
