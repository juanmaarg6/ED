var searchData=
[
  ['union',['Union',['../classDiccionario.html#acc83146c7ed375a4220ac278f9d57dc5',1,'Diccionario']]]
];
