var searchData=
[
  ['clave',['clave',['../structdata.html#aa3298b9b021e026f8663005d2fc19e1a',1,'data']]]
];
