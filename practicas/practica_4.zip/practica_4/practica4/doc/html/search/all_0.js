var searchData=
[
  ['addsignificado_5fpalabra',['AddSignificado_Palabra',['../classDiccionario.html#a7e167da231bff610001df3c20cc9b7a7',1,'Diccionario']]]
];
