var indexSectionsWithContent =
{
  0: "abcdegimosu~",
  1: "cdgi",
  2: "dgu",
  3: "abcdegimosu~",
  4: "ci",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Amigas"
};

