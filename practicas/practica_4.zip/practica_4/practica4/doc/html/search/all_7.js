var searchData=
[
  ['main',['main',['../usodiccionario_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;usodiccionario.cpp'],['../usoguia_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;usoguia.cpp']]],
  ['modificar_5ftelefono',['modificar_telefono',['../classGuia__Tlf.html#a0aebb2e115c29d784846a05c391bc002',1,'Guia_Tlf::modificar_telefono(const string &amp;nombre, const string &amp;tlf)'],['../classGuia__Tlf.html#a073b19447f0cdfc2a8b34ada08257c87',1,'Guia_Tlf::modificar_telefono(const string &amp;nombre, const string &amp;tlf_antiguo, const string &amp;tlf_nuevo)']]]
];
