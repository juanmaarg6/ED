var searchData=
[
  ['begin',['begin',['../classDiccionario.html#aacd300de3e06e12e8f213df624fdd46e',1,'Diccionario::begin()'],['../classGuia__Tlf.html#a2a325e84f226b0c9776115da309493ba',1,'Guia_Tlf::begin()']]],
  ['borrar',['borrar',['../classGuia__Tlf.html#a57e32bbc9e76567d22e5275d4d2a6515',1,'Guia_Tlf::borrar(const string &amp;nombre)'],['../classGuia__Tlf.html#af8adac24fd35985b9016a4a38cca60f4',1,'Guia_Tlf::borrar(const string &amp;nombre, const string &amp;tlf)']]],
  ['borrarporclave',['BorrarPorClave',['../classDiccionario.html#a40b8170593e0904af0c603f2ca78882c',1,'Diccionario']]]
];
