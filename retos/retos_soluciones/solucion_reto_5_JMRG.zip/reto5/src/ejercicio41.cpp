/**
 * @file ejercicio41.cpp
 * @brief Implementaci�n de la funci�n:
 *          
 *           int enquenivel(bintree<int>::node w, bintree<int> &A);
 *
 *        que devuelve el nivel del nodo w en el �rbol A (la ra�z est� a 
 *        nivel 0).
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include "../bintree/bintree.h"

using namespace std;

/**
 * @brief Devuelve el nivel del nodo w en el �rbol A
 * @param w Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return Nivel del nodo w en el �rbol A
 */
int enquenivel(bintree<int>::node w, bintree<int> &A) {
	
	if( w.parent().null() )
		return 0;
	else {
		int nivel_nodo = enquenivel(w.parent(), A);
		return (1 + nivel_nodo);	
	}
}

int main() {
	
	/*
	// Creamos el �rbol:
	//
  	//        		        10
  	//     		        /       \
  	//                11        30
  	//              /    \    /    \
  	//             5     13  33    35
  	//           /  \     \   \
  	//          1    9     16  25
  	//                \
  	//                 7
  	//
  	*/
  	
  	bintree<int> Arb(10);
  	Arb.insert_left(Arb.root(), 11);
  	Arb.insert_left(Arb.root().left(), 5);
  	Arb.insert_left(Arb.root().left().left(), 1);
	Arb.insert_right(Arb.root().left().left(), 9);
	Arb.insert_right(Arb.root().left().left().right(), 7);
  	Arb.insert_right(Arb.root().left(), 13);
  	Arb.insert_right(Arb.root().left().right(), 16);
  	Arb.insert_right(Arb.root(), 30);
  	Arb.insert_left(Arb.root().right(), 33);
  	Arb.insert_right(Arb.root().right().left(), 25);
  	Arb.insert_right(Arb.root().right(), 35);
 
	// Mostramos el �rbol en preorden
	cout << "Preorden: ";
  	for(bintree<int>::preorder_iterator i = Arb.begin_preorder(); 
	    i != Arb.end_preorder(); ++i) {
	    	
    	cout << *i << " ";
    }
	cout << endl << endl;
	
	// Prueba de la funci�n enquenivel()
  	bintree<int>::node nodo1 =  Arb.root();
  	bintree<int>::node nodo2 =  Arb.root().left();
  	bintree<int>::node nodo3 =  Arb.root().right().left();
  	bintree<int>::node nodo4 =  Arb.root().left().right().right();
  	bintree<int>::node nodo5 =  Arb.root().left().left().right().right();

	cout << "Nodo con etiqueta " << *nodo1 << " --> Nivel " 
	     << enquenivel(nodo1, Arb) << endl;
	cout << "Nodo con etiqueta " << *nodo2 << " --> Nivel " 
	     << enquenivel(nodo2, Arb) << endl;
	cout << "Nodo con etiqueta " << *nodo3 << " --> Nivel " 
	     << enquenivel(nodo3, Arb) << endl;
	cout << "Nodo con etiqueta " << *nodo4 << " --> Nivel " 
	     << enquenivel(nodo4, Arb) << endl;
	cout << "Nodo con etiqueta  " << *nodo5 << " --> Nivel " 
	     << enquenivel(nodo5, Arb) << endl;
	
	return 0;	
}
