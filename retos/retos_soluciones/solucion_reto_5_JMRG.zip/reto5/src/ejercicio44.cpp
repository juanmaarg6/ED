/**
 * @file ejercicio44.cpp
 * @brief Se define el volumen de un �rbol binario como el n�mero de hojas 
 *        multiplicado por la altura del �rbol. 
 * 
 *        Implementaci�n de la funci�n:
 *
 *          bool tienenigualvolumen(bintree<int> A, bintree<int> B);
 *
 *        que devuelve true si 2 �rboles binarios diferentes A y B tienen el 
 *        mismo volumen
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include "../bintree/bintree.h"

using namespace std;

/**
 * @brief Devuelve el nivel del nodo w en el �rbol A
 * @param w Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return Nivel del nodo w en el �rbol A
 */
int enquenivel(bintree<int>::node w, bintree<int> &A) {
	
	if( w.parent().null() )
		return 0;
	else {
		int nivel_nodo = enquenivel(w.parent(), A);
		return (1 + nivel_nodo);	
	}
}

/**
 * @brief Comprueba si un nodo v de un �rbol A es una hoja
 * @param v Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return True (1) si el nodo v del �rbol A es una hoja y
 *         False (0) si no
 */
bool EsHoja(bintree<int>::node v, bintree<int> &A) {
	
	return ( v.left().null() && v.right().null() );
}

/**
 * @brief Devuelve la altura de un nodo w de un �rbol A
 * @param w Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return Altura del nodo w en el �rbol A
 */
int getAltura(bintree<int>::node w, bintree<int> A) {
	
	int izda, dcha;
	bintree<int>::node nodo_nulo;
	
	if(w == nodo_nulo)
		return -1;
	else {
		izda = getAltura(w.left(), A);
		dcha = getAltura(w.right(), A);
		return ( 1 + (izda > dcha ? izda : dcha) );
	}
}

/**
 * @brief Devuelve el n�mero de hojas que se encuentran a partir de
 *        un nodo w de un �rbol A
 * @param w Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return N�mero de hojas que se encuentran a partir del nodo w del �rbol A
 */
int getNumeroDeHojas( bintree<int>::node v, bintree<int> A) {
	
	int numero_hojas = 0;
	bintree<int>::node nodo_nulo;

	if( EsHoja(v, A) )
		return 1;
	else {
		
		if(v.left() != nodo_nulo)
			numero_hojas += getNumeroDeHojas(v.left(), A);
		
		if(v.right() != nodo_nulo)
			numero_hojas += getNumeroDeHojas(v.right(), A);
	}
	
	return numero_hojas;
}

/**
 * @brief Devuelve el volumen de un �rbol A
 * @param A �rbol binario de enteros
 * @return Volumen del �rbol A
 */
int getVolumen(bintree<int> A) {
	
	return ( getAltura(A.root(), A) * getNumeroDeHojas(A.root(), A) );
}

/**
 * @brief Comprueba si dos �rboles A y B tienen el mismo volumen
 * @param A �rbol binario de enteros 1
 * @param B �rbol binario de enteros 2
 * @return True (1) si el volumen del �rbol A coincide con el volumen del
 *         �rbol B y False (0) si no
 */
bool tienenigualvolumen(bintree<int> A, bintree<int> B) {
	
	return (getVolumen(A) == getVolumen(B));
}

int main() {
	
	/* 
	// Creamos el �rbol 1:
	//
  	//        					1
  	//     					 /    \
  	//    					2      3
  	//
  	*/
  	
  	bintree<int> Arb1(1);
  	Arb1.insert_left(Arb1.root(), 2);
  	Arb1.insert_right(Arb1.root(), 3);
  	
	/* 
	// Creamos el �rbol 2:
	//
  	//        					1
  	//     					 /    \
  	//    					2      3
  	// 			    		  \
  	//						   3		 
  	//						 /   \
  	//                      4     5
  	//
  	*/
  	
  	bintree<int> Arb2(1);
  	Arb2.insert_left(Arb2.root(), 2);
  	Arb2.insert_right(Arb2.root().left(), 3);
  	Arb2.insert_left(Arb2.root().left().right(), 4);
  	Arb2.insert_right(Arb2.root().left().right(), 5);

	// Mostramos el �rbol 1 en preorden
	cout << "Preorden del arbol 1: ";
  	for(bintree<int>::preorder_iterator i = Arb1.begin_preorder(); 
	    i != Arb1.end_preorder(); ++i) {
	    	
    		cout << *i << " ";
    	}
	cout << endl;

	// Mostramos el �rbol 2 en preorden
	cout << "Preorden del arbol 2: ";
  	for(bintree<int>::preorder_iterator i = Arb2.begin_preorder(); 
	    i != Arb2.end_preorder(); ++i) {
	    	
    		cout << *i << " ";
    	}
	cout << endl << endl;

	// Prueba de la funci�n tienenigualvolumen()
	
	cout << "Volumen del arbol 1 --> " << getVolumen(Arb1) << endl;
	cout << "Volumen del arbol 2 --> " << getVolumen(Arb2) << endl << endl;
	
  	if( tienenigualvolumen(Arb1, Arb2) )
  		cout << "Ambos arboles tienen el mismo volumen";
  	else
  		cout << "Ambos arboles no tienen el mismo volumen";

	cout << endl;
  		
	return 0;	
}
