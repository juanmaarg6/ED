/**
 * @file ejercicio40.cpp
 * @brief Implementaci�n de una funci�n no recursiva para recorrer un �rbol 
 *        binario en preorden 
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include <stack>
#include "../bintree/bintree.h"

using namespace std;

/**
 * @brief Muestra en preorden un �rbol A
 * @param A �rbol binario de enteros
 */
void PreordenNoRecursivo(const bintree<int> &A) {
	
	bintree<int>::node actual;
	bintree<int>::node nodo_nulo;
	stack<bintree<int>::node> p;
	
	// Le a�adimos a la pila un nodo nulo
	actual = nodo_nulo;
	p.push(actual);
	
	// El nodo actual pasa a ser la ra�z del �rbol A
	actual = A.root();
	
	// Recorremos todos los nodos del �rbol hasta que el nodo actual sea
	// el nodo nulo que a�adimos en la pila
	while(actual != nodo_nulo) {
		
		// Mostramos la etiqueta del nodo del �rbol
		cout << *actual << " ";
		
		// Si el hijo derecho del nodo actual no es nulo, lo a�adimos a la pila
		if(actual.right() != nodo_nulo) 
			p.push( actual.right() );
		
		// Si el hijo izquierda del nodo actual no es nulo, dicho hijo
		// izquierda pasa a ser el nodo actual. Si es nulo, el nodo actual pasa
		// a ser igual al tope de la pila y eliminamos dicho tope de la pila
		if(actual.left() != nodo_nulo)
			actual = actual.left();
		else {
			actual = p.top();
			p.pop();
		}
	}	
}

/**
 * @brief Funci�n principal
 */
int main() {
	
	/*
	// Creamos el �rbol:
	//
  	//        		        10
  	//     		        /       \
  	//                11        30
  	//              /    \    /    \
  	//             5     13  33    35
  	//           /  \     \   \
  	//          1    9     16  25
  	//                \
  	//                 7
  	//
  	*/
  	
  	bintree<int> Arb(10);
  	Arb.insert_left(Arb.root(), 11);
  	Arb.insert_left(Arb.root().left(), 5);
  	Arb.insert_left(Arb.root().left().left(), 1);
	Arb.insert_right(Arb.root().left().left(), 9);
	Arb.insert_right(Arb.root().left().left().right(), 7);
  	Arb.insert_right(Arb.root().left(), 13);
  	Arb.insert_right(Arb.root().left().right(), 16);
  	Arb.insert_right(Arb.root(), 30);
  	Arb.insert_left(Arb.root().right(), 33);
  	Arb.insert_right(Arb.root().right().left(), 25);
  	Arb.insert_right(Arb.root().right(), 35);

	// Mostramos el �rbol en preorden
	cout << "Preorden (iteradores): ";
  	for(bintree<int>::preorder_iterator i = Arb.begin_preorder(); 
	    i != Arb.end_preorder(); ++i) {
	    	
    	cout << *i << " ";
    }
	cout << endl << endl;
	
	// Prueba de la funci�n PreordenNoRecursivo()
	cout << "Preorden (funcion no recursiva): ";
	PreordenNoRecursivo(Arb);
  	cout << endl;

	return 0;	
}
