/**
 * @file ejercicio36.cpp
 * @brief Implementaci�n de la funci�n:
 *
 *          bintree<int>::node AMC(bintree<int> &A, bintree<int>::node v, 
 *                                 bintree<int>::node w); 
 *
 *        que dados 2 nodos v y w de un �rbol binario A, devuelve su ancestro 
 *        com�n m�s cercano (nodo de mayor profundidad que tiene tanto a v como 
 *        a w como descendientes, entendiendo como caso l�mite que un nodo es 
 *        descendiente de s� mismo).
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include "../bintree/bintree.h"

using namespace std;

/**
 * @brief Devuelve el nivel del nodo w en el �rbol A
 * @param w Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return Nivel del nodo w en el �rbol A
 */
int enquenivel(bintree<int>::node w, bintree<int> &A) {
	
	if( w.parent().null() )
		return 0;
	else {
		int nivel_nodo = enquenivel(w.parent(), A);
		return (1 + nivel_nodo);	
	}
}

/**
 * @brief Devuelve el ancestro com�n m�s cercano de dos nodos v y w
 * @param v Nodo 1 del �rbol A
 * @param w Nodo 2 del �rbol A
 * @param A �rbol binario de enteros
 * @return Ancestro com�n m�s cercano de los nodos v y w
 */
bintree<int>::node AMC(bintree<int> &A, bintree<int>::node v,
					   bintree<int>::node w) {
    
	bintree<int>::node ancestro;

    // Caso l�mite
    if(v == w)
        return v;
        
    // Hacemos que ambos est�n en el mismo nivel
    int nivel_nodo_v = enquenivel(v, A);
	int nivel_nodo_w = enquenivel(w, A);
	
    if(nivel_nodo_v < nivel_nodo_w)
        for( int i = 0; i < (nivel_nodo_w - nivel_nodo_v); ++i)
            w = w.parent();
    if(nivel_nodo_v > nivel_nodo_w)
        for(int i = 0; i < (nivel_nodo_v - nivel_nodo_w); ++i)
            v = v.parent();
	
	// Encontrar el ancestro com�n m�s cercano ser� ir subiendo en los
    // padres de cada uno hasta que coincidan
    bool continuar = true;
    
    while(continuar) {
        v = v.parent();
        w = w.parent();
        
        if(v == w) {
            ancestro = v;
            continuar = false;
        }
    }
    
    return ancestro;
}

/**
 * @brief Funci�n principal
 */
int main() {
	
	/*
	// Creamos el �rbol:
	//
  	//        		        10
  	//     		        /       \
  	//                11        30
  	//              /    \    /    \
  	//             5     13  33    35
  	//           /  \     \   \
  	//          1    9     16  25
  	//                \
  	//                 7
  	//
  	*/
  	
  	bintree<int> Arb(10);
  	Arb.insert_left(Arb.root(), 11);
  	Arb.insert_left(Arb.root().left(), 5);
  	Arb.insert_left(Arb.root().left().left(), 1);
	Arb.insert_right(Arb.root().left().left(), 9);
	Arb.insert_right(Arb.root().left().left().right(), 7);
  	Arb.insert_right(Arb.root().left(), 13);
  	Arb.insert_right(Arb.root().left().right(), 16);
  	Arb.insert_right(Arb.root(), 30);
  	Arb.insert_left(Arb.root().right(), 33);
  	Arb.insert_right(Arb.root().right().left(), 25);
  	Arb.insert_right(Arb.root().right(), 35);

	// Mostramos el �rbol en preorden
	cout << "Preorden: ";
  	for(bintree<int>::preorder_iterator i = Arb.begin_preorder(); 
	    i != Arb.end_preorder(); ++i) {
	    	
    	cout << *i << " ";
    }
	cout << endl << endl;
	
	// Prueba 1 de la funci�n AMC()
  	bintree<int>::node nodo1 = Arb.root().left().left().right().right(); 
  	bintree<int>::node nodo2 = Arb.root().left().right().right();
  	
  	cout << "AMC(" << *nodo1 << ", " << *nodo2 << ") --> "
  	     << ( *AMC(Arb, nodo1, nodo2) );
  	
  	cout << endl;
  	
  	// Prueba 2 de la funci�n AMC()
  	bintree<int>::node nodo3 = Arb.root().left().left().right().right();
  	bintree<int>::node nodo4 = Arb.root().right().left().right();
  	
  	cout << "AMC(" << *nodo3 << ", " << *nodo4 << ") --> "
  	     << ( *AMC(Arb, nodo3, nodo4) ) << endl;
  	  	
	return 0;	
}
