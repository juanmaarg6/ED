/**
 * @file ejercicio39.cpp
 * @brief Se define la �trayectoria� de una hoja en un �rbol binario como la 
 *        suma de las etiquetas en el camino desde la raiz a dicha hoja 
 *        multiplicadas por el nivel en que est� cada nodo en ese camino. 
 *
 *        Implementaci�n de la funci�n:
 *
 *               bintree<int>::node trayectoria(bintree<int> &A);
 *
 *        que devuelve la hoja con mayor valor de trayectoria.
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include "../bintree/bintree.h"

using namespace std;

/**
 * @brief Devuelve el nivel del nodo w en el �rbol A
 * @param w Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return Nivel del nodo w en el �rbol A
 */
int enquenivel(bintree<int>::node w, bintree<int> &A) {
	
	if( w.parent().null() )
		return 0;
	else {
		int nivel_nodo = enquenivel(w.parent(), A);
		return (1 + nivel_nodo);	
	}
}

/**
 * @brief Comprueba si un nodo v de un �rbol A es una hoja
 * @param v Nodo del �rbol A
 * @param A �rbol binario de enteros
 * @return True (1) si el nodo v del �rbol A es una hoja y
 *         False (0) si no
 */
bool EsHoja(bintree<int>::node v, bintree<int> &A) {
	
	return ( v.left().null() && v.right().null() );
}

/**
 * @brief Devuelve la hoja con mayor valor de trayectoria de un �rbol A
 * @param A �rbol binario de enteros
 * @return Hoja con mayor valor de trayectoria del �rbol A
 */
bintree<int>::node trayectoria(bintree<int> &A) {

	int trayectoria_hoja = 0;
	
	bintree<int>::node hoja_maxima_trayectoria;
	int maxima_trayectoria_hoja = 0;
	
	bintree<int>::postorder_iterator it;

	for(it = A.begin_postorder(); it != A.end_postorder(); ++it) {
		
		if( EsHoja(it.getNodo(), A) ) {
			
			// Hoja del �rbol A
			bintree<int>::node n = it.getNodo();
			
			// Trayectoria de la hoja del �rbol A
			while( !n.null() ) {
				
				trayectoria_hoja += (*n) * (enquenivel(n, A) + 1);
								
				n = n.parent();
			}
			
			// Hoja con m�xima trayectoria del �rbol A			
			if( trayectoria_hoja >  maxima_trayectoria_hoja) {
				maxima_trayectoria_hoja = trayectoria_hoja;
				hoja_maxima_trayectoria = *it.getNodo();
			}
			
			trayectoria_hoja = 0;
		}
	}
  	
	return hoja_maxima_trayectoria;	
}

/**
 * @brief Funci�n principal
 */
int main() {
	
	/*
	// Creamos el �rbol:
	//
  	//        		        7
  	//     		        /       \
  	//                 1         3
  	//              /         /    \
  	//             4         2      1
  	//
  	*/
  	
  	bintree<int> Arb(7);
  	Arb.insert_left(Arb.root(), 1);
   	Arb.insert_right(Arb.root(), 3);
  	Arb.insert_left(Arb.root().left(), 4);
  	Arb.insert_left(Arb.root().right(), 2);
  	Arb.insert_right(Arb.root().right(), 1);

	// Mostramos el �rbol en preorden
	cout << "Preorden: ";
  	for(bintree<int>::preorder_iterator i = Arb.begin_preorder(); 
	    i != Arb.end_preorder(); ++i) {
	    	
    	cout << *i << " ";
    }
	cout << endl << endl;
  	
  	// Prueba de la funci�n trayectoria()
  	bintree<int>::node nodo_max_trayectoria = trayectoria(Arb);
  	
  	cout << "Etiqueta de la hoja con mayor valor de trayectoria --> " 
	     << *nodo_max_trayectoria << endl;
  	  	
	return 0;	
}
