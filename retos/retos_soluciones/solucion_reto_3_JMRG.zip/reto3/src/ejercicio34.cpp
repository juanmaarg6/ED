/**
 * @file ejercicio34.cpp
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include <list>

using namespace std;

/**
 * @brief Comprueba si la lista L1 es igual que la lista L2, es decir,
 *        si tienen el mismo numero de elementos y los elementos en las
 *        posiciones correspondientes son iguales
 * @param L1 Primera lista de enteros
 * @param L2 Segunda lista de enteros
 * @return True (1) si la lista L1 es igual que la lista L2 y 
 *         False (0) si no lo es
 */
bool listas_iguales(list<int> & L1, list<int> & L2) {
	
	list<int>::iterator it1 = L1.begin();
	list<int>::iterator it2 = L2.begin();
	
	bool L1_es_igual_que_L2 = true;
	
	if( L1.size() == L2.size() ) {
		
		while(L1_es_igual_que_L2 && ( it1 != L1.end() ) ) {
			
			if( (*it1) != (*it2) )
				L1_es_igual_que_L2 = false;
				
			it1++;
			it2++;
		}
	}
	else
		L1_es_igual_que_L2 = false;
		
	return L1_es_igual_que_L2;
}

/**
 * @brief Comprueba si la lista L1 es mayor que la lista L2 en
 *        sentido "lexicografico"
 * @param L1 Primera lista de enteros
 * @param L2 Segunda lista de enteros
 * @return True (1) si la lista L1 es mayor que la lista L2 en sentido 
 *         "lexicografico" y False (0) si no lo es
 */
bool lexicord(list<int> & L1, list<int> & L2) {
	
	list<int>::iterator it1 = L1.begin();
	list<int>::iterator it2 = L2.begin();
	
	bool L1_es_mayor_que_L2 = true;

	if( L1.size() < L2.size() )
		while( L1_es_mayor_que_L2 && it1 != L1.end() ) {
			
			if( (*it1) < (*it2) )
				L1_es_mayor_que_L2 = false;
				
			it1++;
			it2++;
		}
	
	if( L1.size() >= L2.size() )
		while( L1_es_mayor_que_L2 && it2 != L2.end() ) {
			
			if( (*it1) < (*it2) )
				L1_es_mayor_que_L2 = false;
				
			it1++;
			it2++;
		}
		
	if( listas_iguales(L1, L2) )
		L1_es_mayor_que_L2 = false;
		
	return L1_es_mayor_que_L2;
}

/**
 * @brief Funcion principal
 */
int main() {
	
	list<int> L1, L2, L3, L4, L5, L6;
	list<int>::iterator it1, it2, it3, it4, it5, it6;
	
	L1 = {1, 3, 2, 4, 6};
	L2 = {1, 3, 2, 5};
	
	it1 = L1.begin();
	it2 = L2.begin();
	
	cout << " Lista 1: ";
	while(it1 != L1.end()) {
		
		cout << *it1 << " ";	
		it1++;
	}
	
	cout << endl;
	cout << " Lista 2: ";
	while(it2 != L2.end()) {
		
		cout << *it2 << " ";	
		it2++;
	}
	
	cout << endl << endl;
	cout << " Lista 1 mayor que lista 2 en sentido 'lexicografico': "
	     << lexicord(L1, L2) << endl << endl;
	
	L3 = {1, 3, 3, 4, 5};
	L4 = {1, 3, 3};
	
	it3 = L3.begin();
	it4 = L4.begin();
	
	cout << " Lista 3: ";
	while(it3 != L3.end()) {
		
		cout << *it3 << " ";	
		it3++;
	}	
	
	cout << endl;
	cout << " Lista 4: ";
	while(it4 != L4.end()) {
		
		cout << *it4 << " ";	
		it4++;
	}	
	
	cout << endl << endl;
	cout << " Lista 3 mayor que lista 4 en sentido 'lexicografico': "
	     << lexicord(L3, L4) << endl << endl;
		 	
	L5 = {1, 2, 3, 4};
	L6 = {1, 2, 3, 4};
	
	it5 = L5.begin();
	it6 = L6.begin();
	
	cout << " Lista 5: ";
	while(it5 != L5.end()) {
		
		cout << *it5 << " ";	
		it5++;
	}	
	
	cout << endl;
	cout << " Lista 6: ";
	while(it6 != L6.end()) {
		
		cout << *it6 << " ";	
		it6++;
	}
	
	cout << endl << endl;
	cout << " Lista 5 mayor que lista 6 en sentido 'lexicografico': "
	     << lexicord(L5, L6) << endl << endl;
	     
	return 0;
}
