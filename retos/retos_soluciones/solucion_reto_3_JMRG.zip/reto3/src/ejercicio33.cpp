/**
 * @file ejercicio33.cpp
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include <list>

using namespace std;

/**
 * @brief Calcula la distancia entre las posiciones del minimo y del maximo
 *        de la lista L
 * @param L Lista de enteros
 * @return Distancia entre las posiciones del minimo y del maximo de la lista
 */
int dminmax(list<int> & L) {
	
	list<int>::iterator it = L.begin();

	pair<int, int> min = {0, *( L.begin() )};
	pair<int, int> max = min;

	int pos = 0;
		
	while(it != L.end()) {
		
		if( (*it) < min.second )
			min = {pos,  *it};
			
		if( (*it) >= max.second )
			max = {pos, *it};
			
		pos++;
		it++;	
	}
	
	int dminmax = max.first - min.first;

	return dminmax;
}

/**
 * @brief Funcion principal
 */
int main() {
	
	list<int> L1, L2, L3;
	list<int>::iterator it1, it2, it3;
	
	L1 =  {5, 1, 3, 2, 4, 7, 6};
	
	it1 = L1.begin();

	cout << " Lista 1: ";
	while(it1 != L1.end()) {
		
		cout << *it1 << " ";	
		it1++;
	}
	
	cout << endl;
	cout << " Distancia entre las posiciones del minimo y del maximo"
	     << " de la lista 1: ";
	cout << dminmax(L1);
	
	L2 = {5, 9, 3, 2, 4, 1, 6};
	
	it2 = L2.begin();
	
	cout << endl << endl;
	cout << " Lista 2: ";
	while(it2 != L2.end()) {
		
		cout << *it2 << " ";	
		it2++;
	}
	
	cout << endl;
	cout << " Distancia entre las posiciones del minimo y del maximo"
	     << " de la lista 2: ";
	cout << dminmax(L2);
		
	L3 = {7, 5, 1, 3, 2, 1, 4, 7, 6};
	
	it3 = L3.begin();
	
	cout << endl << endl;
	cout << " Lista 3: ";
	while(it3 != L3.end()) {
		
		cout << *it3 << " ";	
		it3++;
	}
	
	cout << endl;
	cout << " Distancia entre las posiciones del minimo y del maximo"
	     << " de la lista 3: ";
	cout << dminmax(L3);
	
	cout << endl << endl;

	return 0;	
}
