/**
 * @file ejercicio40.cpp
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include <list>

using namespace std;

/**
 * @brief Calcula el valor de la mayor suma de entre todas las posibles
 *        sumas de sublistas de longitud m a partir de la lista L
 * @param L Lista de enteros
 * @param m Longitud de las sublistas
 * @pre 0 < m <= L.size()
 * @return Valor de la mayor suma de entre todas las posibles sumas de 
 *         sublistas de longitud m a partir de la lista L
 */
int max_sublist_m(list<int> & L, int m) {
	
	list<int>::iterator it = L.begin();
	
	int suma = 0;
	int maxima_suma = 0;
	int contador = 0;
	int longitud_lista = L.size();
		
	while( it != L.end() && (contador + m <= longitud_lista) ) {
		
		list<int>::iterator aux = it;
		suma = 0;
				
		for(int i = 0; i < m; i++) {
	    	suma += *aux;
	    	aux++;
	    }
	    
	    if (suma > maxima_suma)
	        maxima_suma = suma;
	    
	    contador++;
	    it++;
	}
		
	return maxima_suma;	
}

/**
 * @brief Funcion principal
 */
int main() {
	
	list<int> L;
	list<int>::iterator it;

	L = {1, 2, -5, 4, -3, 2};
	
	int longitud_lista = L.size();
	it = L.begin();
	
	cout << " Lista: ";
	while(it != L.end()) {
		
		cout << *it << " ";	
		it++;
	}
	
	cout << endl << endl;
	cout << " Valor de la mayor suma de entre todas las posibles sumas de"
	     <<"sublistas de longitud m: " << endl << endl;
	for(int m = 1; m <= longitud_lista; m++) {
		
		cout << "\t m = " << m << " --> " << max_sublist_m(L, m) << endl;
	}
	
	return 0;
}
