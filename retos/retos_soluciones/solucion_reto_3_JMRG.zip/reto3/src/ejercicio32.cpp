/**
 * @file ejercicio32.cpp
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include <list>

using namespace std;

/**
 * @brief Traslada los primeros n elementos de la lista L al final de la misma
 * @param L Lista de enteros
 * @param n Primeros elementos de la lista
 * @pre 0 <= n <= L.size()
 */
void rotalista(list<int> & L, int n) {
	
	for(int i = 0; i < n; i++){
		L.push_back(*L.begin());
		L.pop_front();
	}
}

/**
 * @brief Funcion principal
 */
int main() {
	
	list<int> L;
	list<int>::iterator it1, it2;
	int n = 2;
		
	L = {1, 3, 5, 4, 2, 6};
	
	it1 = L.begin();

	cout << " Lista inicial: ";
	while(it1 != L.end()) {
		
		cout << *it1 << " ";	
		it1++;
	}
	
	rotalista(L, n);
	
	it2 = L.begin();

	cout << endl << endl;
	
	cout << " Lista tras trasladar los primeros " << n << " elementos al"
	     << " final de la misma: ";
	while(it2 != L.end()) {
		
		cout << *it2 << " ";	
		it2++;
	}
	
	cout << endl << endl;
		
	return 0;	
}
