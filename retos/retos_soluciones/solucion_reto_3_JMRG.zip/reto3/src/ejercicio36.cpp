/**
 * @file ejercicio36.cpp
 * @author Juan Manuel Rodriguez Gomez
 */

#include <iostream>
#include <list>
#include <algorithm>

using namespace std;

/**
 * @brief Comprueba si la lista L1 es un anagrama de la lista L2, es decir,
 *        si L1 y L2 tienen la misma cantidad de elementos y los elementos
 *        de L1 son una permutacion de los de L2
 * @param L1 Primera lista de enteros
 * @param L2 Segunda lista de enteros
 * @return True (1) si la lista L1 es un anagrama de la lista L2 y 
 *         False (0) si no lo es
 */
bool anagrama(list<int> & L1, list<int> & L2) {
	
	list<int>::iterator it = L1.begin();
	
	bool es_anagrama = true;
	
    while(it != L1.end()) {
    	
        if ( find( L2.begin(), L2.end(), *it) == L2.end() )
            es_anagrama = false;

        if ( count( L1.begin(), L1.end(), *it ) != count( L2.begin(), L2.end(), *it ) )
            es_anagrama = false;
            
        it++;
    }

    return es_anagrama;
}

/**
 * @brief Funcion principal
 */
int main() {
	
	list<int> L1, L2, L3, L4;
	list<int>::iterator it1, it2, it3, it4;
	
	L1 = {1, 23, 21, 4, 2, 3, 0};
	L2 = {21, 1, 3, 2, 4, 23, 0};
	
	it1 = L1.begin();
	it2 = L2.begin();
	
	cout << " Lista 1: ";
	while(it1 != L1.end()) {
		
		cout << *it1 << " ";	
		it1++;
	}
	
	cout << endl;
	cout << " Lista 2: ";
	while(it2 != L2.end()) {
		
		cout << *it2 << " ";	
		it2++;
	}
	
	cout << endl << endl;
	cout << " Lista 1 es un anagrama de la lista 2?: " 
	     << anagrama(L1, L2) << endl << endl;
	
	L3 = {1, 3, 5};
	L4 = {4, 5, 4};
	
	it3 = L3.begin();
	it4 = L4.begin();
	
	cout << " Lista 3: ";
	while(it3 != L3.end()) {
		
		cout << *it3 << " ";	
		it3++;
	}	
	
	cout << endl;
	cout << " Lista 4: ";
	while(it4 != L4.end()) {
		
		cout << *it4 << " ";	
		it4++;
	}
	
	cout << endl << endl;	
	cout << " Lista 3 es un anagrama de la lista 4?: " 
	     << anagrama(L3, L4) << endl << endl;
	     
	return 0;	
}
